// Task 1 ============================================
/* Создайте блок div-1. Добавьте на него событие touchstart. Выведите в out-1 слово  touch если событие сработает. */

function t1() {
    document.querySelector(".out-1").innerHTML = "touch";
}

document.querySelector(".div-1").addEventListener("touchstart", t1);

// Task 2 ============================================
/* Создайте блок div-2. Добавьте на него событие touchstart. Выведите в out-2 число срабатываний события. */


function t2() {
    let n = 0;
    return function () {
        document.querySelector(".out-2").innerHTML = n++;
    };
}

document.querySelector(".div-2").addEventListener("touchstart", t2());

// Task 3 ============================================
/*  Создайте блок div-3_1 и div-3_2. Добавьте на них событие touchstart. Выведите в out-3 номер блока 1 или 2 на котором сработало событие. */

function t3() {
    document.querySelector(".out-3").innerHTML = this.getAttribute("data");

}

document.querySelector(".div-3_1").addEventListener("touchstart", t3);
document.querySelector(".div-3_2").addEventListener("touchstart", t3);

// Task 4 ============================================
/*  Создайте блок div-4. И кнопку b-4. При нажатии кнопки - добавляйте событие ontouchstart на блок div-4. При событии происходит вывод текста touch в out-4.  */

function t4() {
    document.querySelector(".div-4").addEventListener("touchstart",
        () => document.querySelector(".out-4").innerHTML = "touch")
}

document.querySelector(".b-4").onclick = t4;

// Task 5 ============================================
/*  Дана кнопка b-5. При ее нажатии очищайте событие ontouchstart на блоке div-4. */

function t5() {
    document.querySelector(".div-4").removeEventListener("touchstart",
        () => document.querySelector(".out-4").innerHTML = "touch")
}

document.querySelector(".b-5").onclick = t5;

// Task 6 ============================================
/*  Добавьте событие ontouchend на div-4. При его срабатывании выведите в out-6 слово touchend. */

function t6() {
    document.querySelector(".out-6").innerHTML = "touchend";
}

document.querySelector(".div-4").addEventListener("touchend", t6);


// Task 7 ============================================
/*  Дан блок div-7. Добавьте событие touch, при срабатывании которого окрашивайте блок в красный цвет. */

function t7() {
    document.querySelector(".div-7").style.background = "red";
}

document.querySelector(".div-7").addEventListener("touchend", t7)

// Task 8 ============================================
/*  Дан блок div-8. Добавьте на него событие touch, которое при срабатывании окрашивает блок случаным цветом из массива a8=[red, green, blue, orange, pink, yellow] */

function t8() {
    const a8 = ['red', 'green', 'blue', 'orange', 'pink', 'yellow'];
    document.querySelector(".div-8").style.background = a8[Math.floor(Math.random() * a8.length)];
}

document.querySelector(".div-8").addEventListener("touchend", t8)


// Task 9 ============================================
/* Дан блок div-9. Добавьте событие ontouch. Выводите количество одновременных касаний в out-9. */

function t9() {
    document.querySelector(".out-9").innerHTML = event.touches.length;
}

document.querySelector(".div-9").addEventListener("touchend", t9);


// Task 10 ============================================
/*  Дан блок div-10. Добавьте на него событие touchmove. При срабатывании события - увеличивайте его ширину на 1. */

function t10() {
    let w = 75;
    return function () {
        w++;
        document.querySelector(".div-10").style.width = w + "px";
    }
}

document.querySelector(".div-10").addEventListener("touchmove", t10());

// Task 11 ============================================
/*  Дан блок div-11. Добавьте на него событие touch. При срабатывании выводите радиус события radiusX, radiusY. */

function t11() {
    document.querySelector(".out-11").innerHTML += `radiusX: ${event.changedTouches[0].radiusX}<br>radiusY: ${event.changedTouches[0].radiusY}`;
}

document.querySelector(".div-11").addEventListener("touchend", t11);


// Task 12 ============================================
/*  Мини проект. Ознакомьтесь с версткой в задании 12. Добавьте touch события так, чтобы при клике на img-12-min картинка появлялась в блоке div-12-max. Если нажимается кнопка prev - то появляется изображение идущее перед текущим. Если нажимается кнопка next - то после текущего. Выбор изображений зациклен.  Изображение, которое сейчас дублируется в большом блоке должно выделяться классом .active-img. Добавьте кнопку reset для сброса состояния, когда выводится первое изображение. Все изображения и начальное состояние - выводится из массива 
    a = [1.png, 2.png, 3.png, 4.png, 5.png, 6.png] - изображения находятся в папке img.
    Усложните задачу - подумайте как в массиве сохранить информацию текст, которая будет выводиться если картинка активна. Сам текст можно сохранять в data-text при отрисовке изображения.
    Источник иконок https://www.iconfinder.com/iconsets/unigrid-phantom-halloween
*/
const a12 = [
    {
        "src": "1.png",
        "data-text": "Черепок"
    },
    {
        "src": "2.png",
        "data-text": "Гарбузяка"
    },
    {
        "src": "3.png",
        "data-text": "Павучок-чарівничок"
    },
    {
        "src": "4.png",
        "data-text": "Тріло"
    },
    {
        "src": "5.png",
        "data-text": "Бульйон"
    },
    {
        "src": "6.png",
        "data-text": "Hello world"
    },
];

const imgs = document.querySelectorAll(".img-12-min");
const imgMax = document.querySelector(".div-12-max>img");
const imgText = document.querySelector(".img-12-text");
const buttonPrev = document.querySelector(".prev");
const buttonNext = document.querySelector(".next");


function t12(img) {
    //видаляэ active-img клас з інших елементів
    document.querySelector(".active-img").classList.remove("active-img");

    //додає active-img клас у вибраний елемент
    img.classList.add("active-img");

    //вкладає src вибраного класу в src .div-12-max>img
    imgMax.src = img.getAttribute("src");

    //додає підпис до картинки
    for (let arr of a12) {
        if (img.getAttribute("src") == `img/${arr["src"]}`) imgText.innerHTML = arr["data-text"];
    }

    //перевірка на існування кнопки reset
    if (!document.querySelector(".b-reset")) addResetButton();
    return img;
}

function addResetButton() {
    let buttonReset = document.createElement("button");
    imgMax.before(buttonReset);
    buttonReset.innerText = "Reset";
    buttonReset.classList.add("button-primary");
    buttonReset.classList.add("b-reset");
    buttonReset.style.background = "orange";
    buttonReset.style.display = "block";

    buttonReset.onclick = () => {
        document.querySelector(".active-img").classList.remove("active-img");
        imgs[0].classList.add("active-img");
        imgMax.src = imgs[0].getAttribute("src");
        imgText.innerHTML = a12[0]["data-text"];
        buttonReset.remove();
    }
    return buttonReset;
}

for (let img of imgs) {
    img.addEventListener("touchstart", function () {
        t12(img);
    });
}
;

buttonPrev.onclick = () => {
    if (document.querySelector(".active-img") === document.querySelector("div-12-wrapper").firstElementChild)
        t12(document.querySelector("div-12-wrapper").lastElementChild);
    else t12(document.querySelector(".active-img").previousElementSibling);
};

buttonNext.onclick = () => {
    if (document.querySelector(".active-img") === document.querySelector("div-12-wrapper").lastElementChild)
        t12(document.querySelector("div-12-wrapper").firstElementChild);
    else t12(document.querySelector(".active-img").nextElementSibling);
};

