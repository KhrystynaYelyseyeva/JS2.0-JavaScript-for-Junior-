//--------1----------
let array1 = ['Hello', 5, true];
console.log(array1);

//--------2----------
let out2 = document.querySelector('#out2');
const array2 = ['abc', 0, false, 'sun'];
out2.innerHTML = array2;

//--------3----------
let out3 = document.querySelector('#out3');
const a = [2, 'hello', 17, 34, 'privet'];
out3.innerHTML = a.length;

//--------4----------
console.log(a[0], a[3], a[8]);

//--------5----------
let out5 = document.querySelector('#out5');
out5.innerHTML = a[0] + a[2] + a[3];

//--------6----------
let out6 = document.querySelector('#out6');
let array6 = ['Kristina ', 'Vodoliy ', 15, 1];
out6.innerHTML = array6;

//--------7----------
let out7 = document.querySelector('#out7');
let b = ['one', 1, 2, 'two'];
b[4] = 'hi';
b[5] = 'foo';
b[6] = 'bar';
out7.innerHTML = b;

//--------8----------
let out8 = document.querySelector('#out8');
let b8 = ['one', 1, 2, 'two'];
b8[3] = 3.14;
b8[4] = 17;
b8[6] = 5;
console.log(b8);
out8.innerHTML = b8 + 'length ' + b8.length;

//--------9----------
let arr9 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
console.log(arr9[2], arr9[6]);

//--------10---------
let out10 = document.querySelector('#out10');
let arr10 = [];
arr10[0] = 1;
arr10[4] = 5;
arr10[9] = 10;
console.log(arr10);
out10.innerHTML = arr10 + 'length ' + arr10.length;

//--------11---------
let out11 = document.querySelector('#out11');
let button11 = document.querySelector('.but_11');
const c = [77, 88, 99, 66];

button11.onclick = () => {
    let x = c[0];
    c[0] = c[2];
    c[2] = x;
    out11.innerHTML = c;
};

//--------12---------
function func12(arr = []) {
    let x = arr[0];
    arr[0] = arr[arr.length - 1];
    arr[arr.length - 1] = x;
    return arr;
};
console.log(func12([1, 2, 3, 4]));


//--------13---------
let out13 = document.querySelector('#out13');
let d = ['y', 4, 22, 'o'];

for (let dd of d) {
    out13.innerHTML += dd + ' ';
}
;

//--------14---------
let out14 = document.querySelector('#out14');
let e = [1, 2, 3, 'hello', 66];

for (let i = e.length - 1; i >= 0; i--) {
    out14.innerHTML += e[i] + ' ';
}
;

//--------15---------
let out15 = document.querySelector('#out15');
let d15 = [0, 2, 5, -4, 6, 22, -9, -12, 8, 12, 13, 78];

for (let i = 0, l = d15.length; i < l; i++) {
    if (d15[i] > 0) out15.innerHTML += d15[i] + ' ';
}
;

//--------16---------
let out16 = document.querySelector('#out16');
let a1 = [], a2 = [];
for (let i = 0, l = d15.length; i < l; i++) {
    if (d15[i] % 2 == 0) a1.push(d15[i]);
    else a2.push(d15[i]);
}
;
out16.innerHTML = 'a1:' + a1 + ";_______a2:" + a2;

//--------17---------
let out17 = document.querySelector('#out17');
let e17 = [3, 0, 2, 6, 0, 1, 3, 1, 9, 0, 2, 0];
let count = 0;

for (let i = 0, l = e17.length; i < l; i++) {
    if (e17[i] === 0) count++;
}
;
out17.innerHTML = count;

//--------18---------
let out18 = document.querySelector('#out18');
let max = 0;
for (let i = 0, l = e17.length; i < l; i++) {
    if (e17[i] > max) max = e17[i];
}
;
out18.innerHTML = max;

//--------19---------
let out19 = document.querySelector('#out19');
let f = [-3, 0, 45, 22, 123, -485, 98, 34];
let maxx = 0, index = 0;
for (let i = 0, l = f.length; i < l; i++) {
    if (f[i] > maxx) {
        maxx = f[i];
        index = i;
    }
}
;
out19.innerHTML = index;

//--------20---------
let out20 = document.querySelector('#out20');
let sum = 0;
for (let i = 0, l = f.length; i < l; i++) {
    sum += f[i];
}
;
out20.innerHTML = sum;