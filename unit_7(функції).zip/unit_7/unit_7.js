//--------1----------
let out1 = document.querySelector('#out1');

out1.onclick = function Name() {
    console.log('--------1----------');
   return  console.log('Kristina');
};

//--------2----------
function Name2(name = 'Kristina') {
   return  console.log(name);
}

console.log('--------2----------');
Name2('Sergey');

//--------3----------
let out3 = document.querySelector('#out3');

function F3(a) {
   return  console.log(a * 10);
};

out3.onclick = () => {
    console.log('--------3----------');
   return  F3(28);
};

//--------4----------
let out4 = document.querySelector('#out4');

function F4() {
   return  out4.style.background = 'red';
}

out4.onclick = () => {
    F4();
};
//--------5----------
let out5 = document.querySelector('#out5>p');
let input5 = document.querySelector('.input_5');

function F5(name) {
  return   out5.innerHTML = name;
};

input5.oninput = () => {
    F5(input5.value);
};

//--------6----------
let out6 = document.querySelector('#out6>p');
let button6 = document.querySelector('.button6');
let inp61 = document.querySelector('.inp_f');
let inp62 = document.querySelector('.inp_s');


function F6(a, b) {
    if (a >= b) out6.innerHTML = a;
    else out6.innerHTML = b;
    return out6;
};

button6.onclick = () => {
    let input61V = +inp61.value;
    let input62V = +inp62.value;

    F6(input61V, input62V);
};

//--------7----------
let out7 = document.querySelector('#out7>p');
let button7 = document.querySelector('.button7');
let inp7 = document.querySelector('.inp_y');


function F7(a) {
    out7.innerHTML = `You are ${2019 - a}.`;
    return out7;
};

button7.onclick = () => {
    let input7V = +inp7.value;

    F7(input7V);
};

//--------8----------
let out8 = document.querySelector('#out8>p');

function F8() {
    out8.innerHTML = Math.round(1 + Math.random() * (10 - 1));
    return out8;
};
F8();

//--------9----------
let out9 = document.querySelector('#out9>p');
let button9 = document.querySelector('.button9');
let inpMin = document.querySelector('.inp_min');
let inpMax = document.querySelector('.inp_max');


function F9(min, max) {
    if (min == max || min > max) out9.innerHTML = 'err';
    else out9.innerHTML = Math.round(min + Math.random() * (max - min));
    return out9;
};

button9.onclick = () => {
    let inpminV = +inpMin.value;
    let inpmaxV = +inpMax.value;

    F9(inpminV, inpmaxV);
};

//--------10---------
let button10 = document.querySelector('#button10');
let input10 = document.querySelector('#input10');

function F10() {

    let letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  /*  input10.value = `#${Math.floor(Math.random() * 255).toString(16)}${Math.floor(Math.random() * 255).toString(16)}${Math.floor(Math.random() * 255).toString(16)}`;
    return input10.value;*/
}

button10.onclick = () => {
    input10.value =F10();
    //F10();
}
;
//--------11---------
let out11 = document.querySelector('#out11>p');

function f11() {
    return 5;
}

function Product11(a, b) {
    return a * b;
}

out11.innerHTML = Product11(f11(), 9);

//--------12---------
let out12 = document.querySelector('#out12>p');
let inp12 = document.querySelector('.inp_12');
let button12 = document.querySelector('.button12')

function toNum(s) {
    return parseInt(s, 10);
}

button12.onclick = () => {
    out12.innerHTML = toNum(inp12.value);
};

//--------13---------
let out13 = document.querySelector('#out13>p');
let inp13 = document.querySelector('.inp_13');
let button13 = document.querySelector('.button13')

function emptyInput(t) {
    if (t == "") return false;
    else return t.replace(/\s+/g, '');
}

button13.onclick = () => {
    out13.innerHTML = emptyInput(inp13.value);
};

//--------14---------
let out14 = document.querySelector('#out14>p');
let inp14 = document.querySelector('.inp_14');
let button14 = document.querySelector('.button14')

function F14(a) {
    if (a % 2 == 0) return true;
    else return false;
}

button14.onclick = () => {
    out14.innerHTML = F14(inp14.value);
};

//--------15---------
let div15 = document.querySelector('#out15>div');

div15.onmousemove = () => {
    console.log('--------15----------');
    return console.log('move');
};

//--------16---------
let div16 = document.querySelector('#out16>div');

div16.onmouseenter = () => {
    console.log('--------16----------');
    return console.log('enter');
};

//--------17---------
let div17 = document.querySelector('#out17>div');

div17.onmouseleave = () => {
    console.log('--------17----------');
    return console.log('leave');
};

//--------18---------
let div18 = document.querySelector('#out18>div');

div18.onclick = function () {
    return this.style.background = 'red';
};

//--------19---------
let div19 = document.querySelector('#out19>div');

div19.onclick = () => {
    return this.style.background = 'red';
};

//--------20---------
let div20 = document.querySelectorAll('div.go');

for (let i = 0, l = div20.length; i < l; i++) {
    div20[i].onclick = function () {
        return this.style.background = 'red';
    };
}