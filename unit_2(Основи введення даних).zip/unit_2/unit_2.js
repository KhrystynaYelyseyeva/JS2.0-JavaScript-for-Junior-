//--------1----------
let a = 7, b = 9;
console.log(a*b);

//--------2----------
let c = 7, d = 9;
document.querySelector('.division').innerHTML = c/d;

//--------3----------
let e = 3, f = 5;
document.querySelector('.add').innerHTML = e + f;

//--------4----------
let e1 = '3', f1 = 5;
document.querySelector('.add1').innerHTML = e1 + f1;

//--------5----------
let e2 = '3', f2 = 0;
document.querySelector('.division1').innerHTML = e2 / f2;

//--------6----------
let e3 = 3, f3 = 'Hello';
document.querySelector('.add3').innerHTML = e3 + f3;

//--------7----------
let e4 = 4, f4 = 'Hello';
document.querySelector('.multiplication').innerHTML = e4*f4;

//--------8----------
let input1 = document.querySelector('.input1'); //input1
let button1 = document.querySelector('.button1'); //button1

button1.onclick = function () {
   console.log(input1.value);
}

//--------9----------
let input2 = document.querySelector('.input2'); //input2
let button2 = document.querySelector('.button2'); //button2
let out2 = document.querySelector('.out2'); //поле виводу запису користувача

button2.onclick = function () {
    out2.innerHTML = input2.value;
    input2.value = '';
}

//--------10---------
let input3 = document.querySelector('.input3'); //input3
let button3 = document.querySelector('.button3'); //button3
let out3 = document.querySelector('.out3'); //поле виводу запису користувача помножене на 10

button3.onclick = function () {
    out3.innerHTML = input3.value * 10;
}

//--------11---------
let input4 = document.querySelector('.input4'); //input4
let button4 = document.querySelector('.button4'); //button4
let out4 = document.querySelector('.out4'); //поле виводу запису користувача + 10

button4.onclick = function () {
    out4.innerHTML = +input4.value + 10;
}

//--------12---------
let firstname = document.querySelector('input[name=firstname]'); //input[name=firstname]
let lastname = document.querySelector('input[name=lastname]'); //input[name=lastname]
let button5 = document.querySelector('.button5'); //button5

button5.onclick = function () {
    console.log('Hello ' + firstname.value + ' ' +  lastname.value);
}

//--------13---------
let firstNum = document.querySelector('input[name=firstnum]'); //input[name=firstnum]
let secondNum = document.querySelector('input[name=secondnum]'); //input[name=secondnum]
let button6 = document.querySelector('.button6'); //button6
let out6 = document.querySelector('.out6'); //поле виводу суми чисел введених користувачем


button6.onclick = function () {
    out6.innerHTML = +firstNum.value + +secondNum.value ;
}

//--------14---------
document.querySelector('.hello').value = 'Hello';

//--------15---------
let y = document.querySelector('.y');
y.style.border = '2px solid red'

//--------16---------


//--------17--------- НЕ ПРАЦЮЄ, повертає NAN
let input17 = document.querySelector('.input17');
let button17 = document.querySelector('.button17');

button17.onclick = () => {
    let t = input17.value;
    t = parseInt(t);
    console.log(t);
}

//--------18---------
let input18 = document.querySelector('.input18');
let button18 = document.querySelector('.button18');

button18.onclick = () => {
    let t = input18.value;
    t = parseFloat(t);
    console.log(t);
}

//--------19---------
let firstNum19 = document.querySelector('input[name=firstnum19]'); //input[name=firstnum19]
let secondNum19 = document.querySelector('input[name=secondnum19]'); //input[name=secondnum19]
let button19 = document.querySelector('.button19'); //button19
let out19 = document.querySelector('.out19'); //поле виводу суми чисел введених користувачем


button19.onclick = function () {
    out19.innerHTML = +firstNum19.value + +secondNum19.value ;
}

//--------20---------
let firstName = document.querySelector('input[name=firstname_]'); //input[name=firstname_]
let lastName = document.querySelector('input[name=lastname_]'); //input[name=lastname_]
let age = document.querySelector('input[name=age]'); //input[name=age]
let job = document.querySelector('input[name=job]'); //input[name=job]
let button20 = document.querySelector('.button20'); //button20

button20.onclick = function () {
    alert('Dear, ' + firstName.value + ' ' + lastName.value + ',  your age is '+ age.value + ' years old, your profession is ' +  job.value);
};
