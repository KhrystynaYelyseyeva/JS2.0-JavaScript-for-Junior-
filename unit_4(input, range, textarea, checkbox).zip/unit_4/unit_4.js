//--------1----------

//--------2----------

//--------3----------

//--------4----------
let checkbox4 = document.querySelector('input[name=checkbox4]'); //input[name=checkbox4]
let button4 = document.querySelector('.button4'); //button4
let out4 = document.querySelector('.out4');

button4.onclick = () => {
    if (checkbox4.checked) out4.innerHTML = true;
    else out4.innerHTML = false;
}

//--------5----------
let checkbox5 = document.querySelector('input[name=checkbox5]'); //input[name=checkbox5]
let button5 = document.querySelector('.button5'); //button5
let out5 = document.querySelector('.out5');

button5.onclick = () => {
    if (checkbox5.checked) out5.innerHTML = checkbox5.value;
}

//--------6----------

//--------7----------

//--------8----------

let button8 = document.querySelector('.button8'); //button8
let out8 = document.querySelector('.out8');

button8.onclick = () => {
    out8.innerHTML = '<input type="text" name="input8"><button class="button82" onclick="alert(document.querySelector(\'input[name=input8]\').value)">PUSH MORE</button>';
}

//--------9----------
let radio9 = document.querySelector('input[name=radio9]'); //input[name=radio9]
let button9 = document.querySelector('.button9'); //button9

button9.onclick = () => {
    if (radio9.checked) alert(radio9.value);
    else alert(false);
}

//--------10---------

//--------11---------

//--------12---------
let date12 = document.querySelector('input[name=date12]'); //input[name=date12]
let button12 = document.querySelector('.button12'); //button12
let out12 = document.querySelector('.out12');

button12.onclick = () => out12.innerHTML = date12.value

//--------13---------
let range13 = document.querySelector('input[name=range13]'); //input[name=range13]
let button13 = document.querySelector('.button13'); //button13
let out13 = document.querySelector('.out13');

button13.onclick = () => {
    out13.innerHTML = range13.value;
};

range13.oninput = () => {
    out13.innerHTML = range13.value;
};

//--------14---------

//--------15---------

//--------16---------
let button16 = document.querySelector('.button16'); //button16
let out16 = document.querySelector('.out16'); //поле виводу результату
let select16 = document.querySelector('#s');

button16.onclick = () => {

    if (select16.options[0].selected) out16.innerHTML = select16.options[0].value;
    else if (select16.options[1].selected) out16.innerHTML = select16.options[1].value;
    else if (select16.options[2].selected) out16.innerHTML = select16.options[2].value;
    else if (select16.options[3].selected) out16.innerHTML = select16.options[3].value;
    else if (select16.options[4].selected) out16.innerHTML = select16.options[4].value;
    else out16.innerHTML = 'incorrect choice';
}
//--------17---------
let out17 = document.querySelector('.out17'); //поле виводу результату
let select17 = document.querySelector('#s2');

select17.onchange = () => {

    if (select17.options[0].selected) out17.innerHTML = select17.options[0].value;
    else if (select17.options[1].selected) out17.innerHTML = select17.options[1].value;
    else if (select17.options[2].selected) out17.innerHTML = select17.options[2].value;
    else if (select17.options[3].selected) out17.innerHTML = select17.options[3].value;
    else if (select17.options[4].selected) out17.innerHTML = select17.options[4].value;
    else out17.innerHTML = 'incorrect choice';
}
//--------18---------

//--------19---------
let input19_1 = document.querySelector('#input19_1');
let input19_2 = document.querySelector('#input19_2');
let button19 = document.querySelector('.button19'); //button19

button19.onclick = () => {
    let input19_1V = input19_1.value;
    let input19_2V = input19_2.value;

    console.log(input19_1V, input19_2V)
}

//--------20---------

let form20 = document.querySelector('.form20').elements;
let button20 = document.querySelector('.button20'); //button20

button20.onclick = () => console.log(form20[0].value, form20[1].value);