//--------1----------
let arr1 = [];
let out1 = document.querySelector('.out-1');
let input1 = document.querySelector('.u-1');

//функція читає рядок з інпут і переписує його в масив
function takeValueFromInpToArr() {
    let input1V = input1.value;
    if (input1V != '') {
        for (let i = 0, l = input1V.length; i < l; i++) {
            arr1.push(input1V[i]);
        }
        return arr1;
    }
}

document.querySelector('.u-2__push').onclick = () => {
    takeValueFromInpToArr();
    out1.innerHTML = arr1;
}

//--------2----------
document.querySelector('.u-2__pop').onclick = () => {
    takeValueFromInpToArr();
    arr1.pop();
    out1.innerHTML = arr1;
}

//--------3----------
document.querySelector('.u-3__shift').onclick = () => {
    takeValueFromInpToArr();
    arr1.shift();
    out1.innerHTML = arr1;
}

//--------4----------
document.querySelector('.u-4__unshift').onclick = () => {
    let input1V = input1.value;
    if (input1V != '') {
        for (let i = 0, l = input1V.length; i < l; i++) {
            arr1.unshift(input1V[i]);
        }
        out1.innerHTML = arr1;
    }
}

//--------5----------
let button5 = document.querySelector('.but-5');
let index = document.querySelector('#index');
let amount = document.querySelector('#amount');
let out5 = document.querySelector('.out-5');

let arr5 = [3, 14, 15, 92, 6, 54, 123, 87, 66, 43, 12, 90, 'hello'];

button5.onclick = () => {
    let indexV = Math.floor(+index.value);
    let amountV = Math.floor(+amount.value);
    if (indexV >= 0 && indexV < 13 && amountV > 0 && amountV < 14) {
        arr5.splice(indexV, amountV);
        out5.innerHTML = arr5;
    }
}

//--------6----------
let button6 = document.querySelector('.but-6');
let input6 = document.querySelector('.inp-6');
let out6 = document.querySelector('.out-6');

function funcPush() {
    let input6V = input6.value;
    let arr6 = [];

    if (input6V != '') {
        let l = input6V.length; // довжина рядка = довжині масиву
        //записуємо інпут у масив
        for (let i = 0; i < l; i++) {
            arr6.push(input6V[i]);
        }

        //присвоюємо масиву новий елемент
        arr6[arr6.length] = 'Inew';

        out6.innerHTML = arr6;

    }
    return 0;
}

button6.onclick = () => {
    funcPush();
};

//--------7----------
let out7 = document.querySelector('.out-7');
let button7 = document.querySelector('.but-7');
let arr7 = ['one', 1, 2, 'two'];

function funcPop() {
    arr7.pop();
    out7.innerHTML = arr7;
    return 0;
};

button7.onclick = () => {
    funcPop();
};

//--------8----------
let out8 = document.querySelector('.out-8');
let button8 = document.querySelector('.but-8');
let arr8 = ['one', 1, 2, 'two'];

function funcShift() {
    arr8.shift();
    out8.innerHTML = arr8;
    return 0;
};

button8.onclick = () => {
    funcShift();
};
//--------9----------
let out9 = document.querySelector('.out-9');
let button9 = document.querySelector('.but-9');
let input9 = document.querySelector('.inp-9');

function funcUnShift() {
    let newElement9 = input9.value;
    arr8.unshift(newElement9);
    out9.innerHTML = arr8;
    return 0;
}

button9.onclick = () => {
    funcUnShift();
}

//--------10---------
let out10 = document.querySelector('.out-10');
let arr10 = [2, 4, 6, 8, 10, 'hello'];
arr10.reverse();
out10.innerHTML = arr10;

//--------11---------
let out11 = document.querySelector('.out-11');
let button11 = document.querySelector('.u-11__button');
let input11 = document.querySelector('.u-11__input');
let arr11 = [0, 2, 3, 7, 8, 5, 11];

button11.onclick = () => {
    let u11 = +input11.value;
    out11.innerHTML = arr11.indexOf(u11);
};

//--------12---------
let out12 = document.querySelector('.out-12');
let button12 = document.querySelector('.but-12');
let input12 = document.querySelector('.inp-12');
let arr12 = ['a', '2', 'n', 's', '0'];//цикл з яким буде порівняння

function funcIndexOf() {
    let input12V = input12.value;
    let arrFromInp = input12V.split('');
    console.log(arrFromInp);
    for (let i = 0, l = arrFromInp.length; i < l; i++) {
        return arr12.indexOf(arrFromInp[i]);//даний метод порівнює строго
    }
};

button12.onclick = () => {
    out12.innerHTML = funcIndexOf();

};

//--------13---------
let out13 = document.querySelector('.out-13');
let arr13 = ['a', 'b', 'c', 'd'];
let arrNew = [];

function funcReverse() {
    arr13.reverse();
    for (let i = 0, l = arr13.length; i < l; i++) {
        arrNew[i] = arr13[i];
    }
    ;
    return arrNew;
}

out13.innerHTML = funcReverse();

//--------14---------
let out14 = document.querySelector('.out-14');
let input14 = document.querySelector('.inp-14');
let button14 = document.querySelector('.but-14');

function F14(n) {
    let arr14 = [];
    for (let i = 0; i < n; i++) {
        arr14[i] = Math.floor(Math.random() * 100);
    }
    ;
    return arr14;
}

button14.onclick = () => {
    let input14V = Math.floor(+input14.value);
    if (input14V > 0) out14.innerHTML = F14(input14V);
}
//--------15---------
let out15 = document.querySelector('.out-15');
let arr15 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
let arr15New = [];

for (let i = 0, l = arr15.length; i < l; i++) {
    if (i % 2 == 0) arr15New.push(arr15[i]);
}
;
out15.innerHTML = arr15New;

//--------16---------
let out16 = document.querySelector('.out-16');
let button16 = document.querySelector('.u-16__button')
let arr16_1 = [3, 5, 7], arr16_2 = [2, 4, 6];

button16.onclick = () => {
    out16.innerHTML = arr16_1.concat(arr16_2);
}

//--------17---------
let out17 = document.querySelector('.out-17');

function funcConcat(arr1 = [], arr2 = []) {
    return arr1.concat(arr2);
}

out17.innerHTML = funcConcat([1, 2], ['a', 'b']);

//--------18---------
let out18 = document.querySelector('.out-18');
let input18 = document.querySelector('.u-18__input');
let button18 = document.querySelector('.u-18__button');
let arr18_1 = ['3', '5', '7', '11', '12', '13', '14'];

button18.onclick = () => {
    let input18V = input18.value.split('');
    for (let i = 0, l = input18V.length; i < l; i++) {
        out18.innerHTML += `${arr18_1.includes(input18V[i])} `;
    }
}


//--------19---------
let out19 = document.querySelector('.out-19');

function funcIncludes(arr1 = [], arr2 = []) {
    for (let i = 0, l = arr1.length; i < l; i++) {
        if (arr1.includes(arr2[i]) == true) {
            out19.innerHTML = true;
            break;
        } else out19.innerHTML = false;
    }
    return 0;
}

funcIncludes([1, 2, 3, 4, 5], [6, 7, 1, 9, 10]);

//--------20---------
let out20 = document.querySelector('.out-20');
let button20 = document.querySelector('.but-20');
let arr20 = ['September', 'October', 'November'];

button20.onclick = () => out20.innerHTML = arr20.join(';');