//--------1----------
for (let i = 1; i < 11; i++) console.log(i);

//--------2----------
for (let i = 1; i < 11; i++) document.querySelector('.out2').innerHTML += i + '  ';

//--------3----------
for (let i = 10; i >= 0; i--) document.querySelector('.out3').innerHTML += i + '  ';

//--------4----------
for (let i = 0; i <= 10; i += 2) document.querySelector('.out4').innerHTML += i + '  ';

//--------5----------
for (let i = 21; i >= 0; i -= 3) document.querySelector('.out5').innerHTML += i + ' ';

//--------6----------
for (let i = 0; i < 6; i++) document.querySelector('.out6').innerHTML += '******' + '<br>';

//--------7----------

let button7 = document.querySelector('.button7');
let input7 = document.querySelector('#input7');
let out7 = document.querySelector('.out7');

button7.onclick = () => {
    for (let i = +input7.value; i > 0; i--) out7.innerHTML += i + '  ';
}

//--------8----------
let input8_1 = document.querySelector('.input8_1');
let input8_2 = document.querySelector('.input8_2');
let button8 = document.querySelector('.button8');
let out8 = document.querySelector('.out8');

button8.onclick = () => {
    for (let i = +input8_1.value; i <= +input8_2.value; i++) out8.innerHTML += i + '  ';
}

//--------9----------
let input9_1 = document.querySelector('.input9_1');
let input9_2 = document.querySelector('.input9_2');
let button9 = document.querySelector('.button9');
let out9 = document.querySelector('.out9');


button9.onclick = () => {
    if (+input9_1.value > +input9_2.value) {
        alert('Err');
    } else {
        for (let i = +input9_1.value; i <= +input9_2.value; i++) out9.innerHTML += i + '  ';
    }
    ;
}

//--------10---------
for (let i = 1902; i <= 1950; i += 2) document.querySelector('.out10').innerHTML += i + ';';

//--------11---------
let one = document.querySelectorAll('.one');
console.log(one.length);

//--------12---------
function changeColor() {
    for (let i = 0, l = one.length; i < l; i++)
        one[i].style.backgroundColor = 'orange';
}

//--------13---------
function showContents() {
    for (let i = 0, l = one.length; i < l; i++)
        console.log(one[i].innerHTML);
}

//--------14---------
let input = document.querySelectorAll('input[type=text]');

function addPlaceholder() {
    for (let i = 0, l = input.length; i < l; i++)
        input[i].setAttribute('placeholder', 'Введите данные');
}

//--------15---------
function inputCount() {
    console.log(input.length);
}

//--------16---------
let out16 = document.querySelector('.out16');
let radio1 = document.querySelectorAll('input[name="p1"]');

function radioValue() {
    for (let i = 0, l = radio1.length; i < l; i++) {
        out16.innerHTML = radio1[i].value
    }
}

//--------17---------
function radioFirstChecked() {
    radio1[0].setAttribute('checked', 'checked');
}

//--------18---------
function radioChangeValue() {
    for (let i = 0, l = radio1.length; i < l; i++) {
        radio1[i].value = i;
        //  console.log(radio1[i].value)
    }
}

//--------19---------
let radio2 = document.querySelectorAll('input[name="p2"]');

function radioCheckValue() {
    for (let i = 0, l = radio2.length; i < l; i++) {
        if (radio2[i].checked) {
            if (radio2[i].value == "6") console.log(true);
            else console.log(false);
        }
    }
}

//--------20---------

let radio3 = document.querySelectorAll('input[name="p3"]');

    for (let i = 0, l = radio3.length; i < l; i++) {
        radio3[i].oninput =()=>{
            console.log("был изменен input");
        }
    }