//--------1----------
let out1 = document.querySelector('#out1>p');

for (let i = 0; i < 3; i++) {

    for (let k = 0; k < 3; k++) out1.innerHTML += "*";

    out1.innerHTML += " ";
}
;
//--------2----------
let out2 = document.querySelector('#out2>p');

for (let i = 0; i < 3; i++) {

    for (let k = 0; k < 5; k++) out2.innerHTML += "*";

    out2.innerHTML += "<br>";
}
;
//--------3----------
let out3 = document.querySelector('#out3>p');

for (let i = 0; i < 3; i++) {

    for (let k = 0; k < 6; k++) {
        if (k % 2 == 0) out3.innerHTML += "1";
        else out3.innerHTML += "0";
    }

    out3.innerHTML += "<br>";
}
;
//--------4----------
let out4 = document.querySelector('#out4>p');

for (let i = 0; i < 3; i++) {

    for (let k = 0; k < 6; k++) {
        if ((k + 1) % 3 == 0) out4.innerHTML += "x";
        else if (k % 2 == 0) out4.innerHTML += "1";
        else out4.innerHTML += "0";
    }

    out4.innerHTML += "<br>";
}
;
//--------5----------
let out5 = document.querySelector('#out5>p');

for (let i = 0; i < 3; i++) {
    for (let k = 0; k <= i; k++) out5.innerHTML += "*";

    out5.innerHTML += "<br>";
}
;
//--------6----------
let out6 = document.querySelector('#out6>p');

for (let i = 5; i > 0; i--) {
    for (let k = 0; k < i; k++) out6.innerHTML += "*";

    out6.innerHTML += "<br>";
}
;
//--------7----------
let out7 = document.querySelector('#out7>pre');

for (let i = 2; i >= 0; i--) {

    for (let k = 0; k < i; k++) out7.innerHTML += " ";

    out7.innerHTML += "*****<br>";
}
;
//--------8----------
let out8 = document.querySelector('#out8>p');

for (let i = 0; i < 5; i++) {
    if (i < 3) for (let k = 0; k <= i; k++) out8.innerHTML += "*";
    else for (let k = 2; k > (i - 3); k--) out8.innerHTML += "*";

    out8.innerHTML += "<br>";
}
;
//--------9----------
let out9 = document.querySelector('#out9>pre');

for (let i = 0; i < 5; i++) {
    if (i == 0 || i == 4) for (let k = 0; k < 6; k++) out9.innerHTML += "*";
    else for (let j = 0; j < 6; j++) {
        if (j == 0 || j == 5) out9.innerHTML += "*";
        else out9.innerHTML += " ";
    }

    out9.innerHTML += "<br>";
}
;
//--------10---------
let out10 = document.querySelector('#out10>pre');
let button10 = document.querySelector('#button10');
let input10 = document.querySelector('#input10');

button10.onclick = () => {
    let input10V = input10.value;

    for (let i = 0; i < 5; i++) {
        if (i == 0 || i == 4) for (let k = 0; k < 6; k++) out10.innerHTML += input10V;
        else for (let j = 0; j < 6; j++) {
            if (j == 0 || j == 5) out10.innerHTML += input10V;
            else out10.innerHTML += "  ";
        }

        out10.innerHTML += "<br>";
    }
}
;
//--------11---------
let out11 = document.querySelector('#out11>p');

for (let i = 6; i < 8; i++) {
    for (let k = 1; k < 11; k++) {
        out11.innerHTML += `${i}*${k}=${i * k}<br>`;
    }
    out11.innerHTML += '<hr>';
}
//--------12---------
let out12 = document.querySelector('#out12>p');

for (let i = 1; i < 6; i++) {
    for (let k = 1; k < i + 1; k++) {
        out12.innerHTML += `${k}`;
    }
    out12.innerHTML += `<br>`;
}
//--------13---------
let out13 = document.querySelector('#out13>p');

for (let i = 0; i < 5; i++) {
    for (let j = 1; j < 11; j++) {
        for (let k = 1; k < 2; k++) {
            if (j == 10) out13.innerHTML += `${i * j + 10}`;
            else out13.innerHTML += `${i}${j}`;
        }
        out13.innerHTML += ` `;
    }
    out13.innerHTML += `<br>`;
}
//--------14---------
let out14 = document.querySelector('#out14>p');

for (let i = 5; i > 0; i--) {
    for (let k = i; k > 0; k--) out14.innerHTML += `${k} `;

    out14.innerHTML += `<br>`;
}
//--------15---------
let out15 = document.querySelector('#out15>p');

for (let i = 1; i < 6; i++) {
    for (let j = 5 - i; j > 0; j--) out15.innerHTML += `X `;
    for (let k = i; k > 0; k--) out15.innerHTML += `${k} `;

    out15.innerHTML += `<br>`;
}
//--------16---------
let out16 = document.querySelector('#out16>p');

for (let i = 1; i < 6; i++) {
    for (let k = i; k > 0; k--) out16.innerHTML += `${i} `;

    out16.innerHTML += `<br>`;
}
//--------17---------
let out17 = document.querySelector('#out17>p');

for (let i = 5; i > 0; i--) {
    for (let k = 1; k < 7 - i; k++) out17.innerHTML += `${i} `;

    out17.innerHTML += `<br>`;
}
//--------18---------
let out18 = document.querySelector('#out18>p');

for (let i = 5; i > 0; i--) {
    for (let k = 1; k < 7 - i; k++) {
        if (i % 2 == 0) out18.innerHTML += `X `;
        else out18.innerHTML += `${i} `;
    }

    out18.innerHTML += `<br>`;
}
//--------19---------
let out19 = document.querySelector('#out19>pre');

for (let i = 2; i > -1; i--) {
    for (let j = 0; j < i; j++) out19.innerHTML += ' ';
    for (let k = 1; k < 10 - i * 2; k++) out19.innerHTML += `*`;

    out19.innerHTML += `<br>`;
}
//--------20---------
let out20 = document.querySelector('#out20>pre');

for (let i = 1; i < 6; i++) {
    if (i > 0 && i < 4) {
        for (let j = 2; j > i - 1; j--) out20.innerHTML += ' ';
        for (let k = 0; k < i * 2; k++) out20.innerHTML += `*`;
    } else {
        for (let j = 0; j < i - 3; j++) out20.innerHTML += ' ';
        for (let k = 2 ** (6 - i); k > 0; k--) out20.innerHTML += `*`;
    }
    out20.innerHTML += `<br>`;
}