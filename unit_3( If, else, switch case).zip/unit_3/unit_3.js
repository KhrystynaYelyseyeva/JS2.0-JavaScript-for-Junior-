//--------1----------
let a = 4;
if (a == 4) {
    console.log('a == 4');
}
;

//--------2----------
let b = 8, c = 10;
if (b > c) {
    console.log('b are more than c');
} else {
    console.log('c are more than b');
}
;

//--------3----------
if (b > c) {
    console.log('b are more than c');
} else if (b == c) {
    console.log('b == c');
} else {
    console.log('c are more than b');
}
;

//--------4----------
let firstN = document.querySelector('input[name=firstnum]'); //input[name=firstnum]
let secondN = document.querySelector('input[name=secondnum]'); //input[name=secondnum]
let button4 = document.querySelector('.button4'); //button4
let out4 = document.querySelector('.out4'); //поле виводу найбільшого введеного числа

button4.onclick = () => {
    let firstNum = +firstN.value;
    let secondNum = +secondN.value;

    if (firstNum > secondNum) {
        out4.innerHTML = firstNum;
    } else if (firstNum == secondNum) {
        out4.innerHTML = 'numbers are equal';
    } else {
        out4.innerHTML = secondNum;
    }
    ;
}

//--------5----------
let bData = document.querySelector('input[name=bdata]'); //input[name=bdata]
let button5 = document.querySelector('.button5'); //button5
let out5 = document.querySelector('.out5'); //поле виводу віку користувача

button5.onclick = () => {
    let bDataV = +bData.value;

    if (bDataV >= 1900 && bDataV < 2000) {
        out5.innerHTML = 2019 - bDataV;
    } else if (bDataV <= 2019 && bDataV >= 2000) {
        console.log(2019 - bDataV);
    } else {
        alert('Please enter the year from 1900 to 2019');
    }
    ;
}

//--------6----------
let apartment = document.querySelector('input[name=apartment]'); //input[name=apartment]
let button6 = document.querySelector('.button6'); //button6
let out6 = document.querySelector('.out6'); //поле виводу повідомлення про існування квартири

button6.onclick = () => {
    let apartmentV = +apartment.value;

    if (apartmentV >= 1 && apartmentV <= 32) {
        out6.innerHTML = 'Welcome!';
    } else {
        out6.innerHTML = 'Sorry. This apartment number doesn\'t exist.';
    }
    ;
}
//--------7----------
let num = document.querySelector('input[name=number]'); //input[name=number]
let button7 = document.querySelector('.button7'); //button7
let out7 = document.querySelector('.out7'); //поле виводу перевірки числа на значення відносно нуля

button7.onclick = () => {
    let numV = +num.value;

    if (numV > 0) {
        out7.innerHTML = 'Positive number';
    } else if (numV == 0) {
        out7.innerHTML = 'Null';
    } else {
        out7.innerHTML = 'Negative number';
    }
    ;
}

//--------8----------
let pNum = document.querySelector('input[name=pnumber]'); //input[name=pnumber]
let button8 = document.querySelector('.button8'); //button8
let out8 = document.querySelector('.out8'); //поле виводу повідомлення про парність введеного числа

button8.onclick = () => {
    let pNumV = +pNum.value;

    if (pNumV % 2 == 0) {
        out8.innerHTML = 'Even number';
    } else {
        out8.innerHTML = 'Odd number';
    }
    ;
}

//--------9----------
let ppNum = document.querySelector('input[name=ppnumber]'); //input[name=ppnumber]
let power = document.querySelector('input[name=power]'); //input[name=power]
let button9 = document.querySelector('.button9'); //button9
let out9 = document.querySelector('.out9'); //поле виводу введеного числа до введеного стененя

button9.onclick = () => {
    let ppNumV = +ppNum.value;
    let powerV = +power.value;

    if (ppNumV == 0) {
        alert('Please, enter number')
    } else {
        out9.innerHTML = ppNumV ** powerV;
    }
    ;
}

//--------10---------
let name10 = document.querySelector('input[name=name10]'); //input[name=name10]
let button10 = document.querySelector('.button10'); //button10

button10.onclick = () => {
    let name10V = name10.value;
    alert('Hello ' + name10V.replace(/\s+/g, '')); //глобально заміняю пробіли. (/\s/g, '') дає той самий результат, але різниця у використанні є. щоб побачити її треба ввести, щось типу(/\s/g, '#')
    name10.value = '';
}

//--------11---------
let name11 = document.querySelector('input[name=name11]'); //input[name=name11]
let button11 = document.querySelector('.button11'); //button11

button11.onclick = () => {
    let name11V = name11.value;
    name11V = name11V.trim(); //Метод trim() удаляет пробельные символы с начала и конца строки.

    if (name11V == '') {
        alert('Error');
    } else {
        alert(name11V);
    }
    name11.value = '';
}

//--------12---------
let num12 = document.querySelector('input[name=number12]'); //input[name=number12]
let button12 = document.querySelector('.button12'); //button12


button12.onclick = () => {
    let num12V = +num12.value;

    switch (num12V) {
        case 1:
            console.log('one');
            break;
        case 2:
            console.log('two');
            break;
        case 3:
            console.log('three');
            break;
        default :
            console.log('err');
            break;
    }

}

//--------13---------
let num13 = document.querySelector('input[name=input13]'); //input[name=input13]
let button13 = document.querySelector('.button13'); //button13
let out13 = document.querySelector('.out13'); //поле виводу номера вулиці

button13.onclick = () => {
    let num13V = +num13.value;

    if (num13V > 0 && num13V <= 5) out13.innerHTML = '1';
    else if (num13V > 5 && num13V <= 11) out13.innerHTML = '2';
    else if (num13V > 11 && num13V <= 20) out13.innerHTML = '3';
    else out13.innerHTML = 'non-existent';
}

//ця частина коду для передачі даних з input при натискання клавіші enter
num13.addEventListener('keyup', function (event) {
    if (event.keyCode === 13) {
        event.preventDefault();
        document.querySelector('.button13').click();
    }
})

//--------14---------
let input14 = document.querySelector('input[name=input14]'); //input[name=input14]
let button14 = document.querySelector('.button14'); //button14
let out14 = document.querySelector('.out14'); //поле виводу кількості рентген

button14.onclick = () => {
    let input14V = +input14.value;

    if (input14V > 0 && input14V <= 25) out14.innerHTML = 'not detected';
    else if (input14V > 25 && input14V <= 50) out14.innerHTML = 'lymphocyte reduction';
    else if (input14V > 50 && input14V <= 100) out14.innerHTML = 'lethargy and vomiting';
    else if (input14V > 100 && input14V <= 150) out14.innerHTML = 'mortality 5%';
    else if (input14V > 150 && input14V <= 350) out14.innerHTML = 'mortality 50% for 30 days';
    else if (input14V > 350 && input14V <= 600) out14.innerHTML = 'mortality 90% for 2 weeks';
    else out14.innerHTML = 'incorrect value';
}

input14.addEventListener('keyup', function (event) {
    if (event.keyCode === 13) {
        event.preventDefault();
        document.querySelector('.button14').click();
    }
})

//--------15---------
const x = 1, y = 0;
console.log(x && y);
console.log(x || y);

//--------16---------
let input16 = document.querySelector('input[name=input16]'); //input[name=input16]
let button16 = document.querySelector('.button16'); //button16
let out16 = document.querySelector('.out16'); //поле виводу кількості рентген

button16.onclick = () => {
    let input16V = +input16.value;

    if (input16V >= 500 && input16V < 1200) out16.innerHTML = input16V * 2525 / 500;
    else if (input16V >= 1200 && input16V < 1600) out16.innerHTML = input16V * 5050 / 1200;
    else if (input16V >= 1600 && input16V < 1900) out16.innerHTML = input16V * 8275 / 1600;
    else if (input16V >= 1900 && input16V < 2000) out16.innerHTML = input16V * 9675 / 1900;
    else if (input16V == 2000) out16.innerHTML = 11075;
    else out16.innerHTML = 'the correct value from 500 to 2000';
}

input16.addEventListener('keyup', function (event) {
    if (event.keyCode === 13) {
        event.preventDefault();
        document.querySelector('.button16').click();
    }
})

//--------17---------
let input17_1 = document.querySelector('input[name=input17_1]'); //input[name=input17_1]
let input17_2 = document.querySelector('input[name=input17_2]'); //input[name=input17_2]
let button17 = document.querySelector('.button17'); //button17
let out17 = document.querySelector('.out17'); //поле виводу перерахунку валюти

button17.onclick = () => {
    let input17_1V = +input17_1.value;
    let input17_2V = input17_2.value;

    if (input17_2V == 'euro') out17.innerHTML = input17_1V * 0.89;
    else if (input17_2V == 'rub') out17.innerHTML = input17_1V * 63.7;
    else if (input17_2V == 'uah') out17.innerHTML = input17_1V * 24.8;
    else out17.innerHTML = 'incorrect value';
}

//--------18---------
let input18_1 = document.querySelector('input[name=input18_1]'); //input[name=input18_1]
let input18_2 = document.querySelector('input[name=input18_2]'); //input[name=input18_2]
let button18 = document.querySelector('.button18'); //button18
let out18 = document.querySelector('.out18'); //поле виводу перерахунку валюти

button18.onclick = () => {
    let input18_1V = +input18_1.value;
    let input18_2V = input18_2.value;

    switch (input18_2V) {
        case 'euro':
            out18.innerHTML = input18_1V * 0.89;
            break;
        case 'rub':
            out18.innerHTML = input18_1V * 63.7;
            break;
        case 'uah':
            out18.innerHTML = input18_1V * 24.8;
            break;
        default:
            out18.innerHTML = 'incorrect value';
    }
}
//--------19---------
let input19_1 = document.querySelector('input[name=input19_1]'); //input[name=input19_1]
let input19_2 = document.querySelector('input[name=input19_2]'); //input[name=input19_2]
let button19 = document.querySelector('.button19'); //button19
let out19 = document.querySelector('.out19'); //поле виводу результату
let select = document.querySelector('#sign');//вибір операції

button19.onclick = () => {
    let input19_1V = +input19_1.value;
    let input19_2V = +input19_2.value;

    if (select.options[1].selected) out19.innerHTML = input19_1V + input19_2V;
    else if (select.options[2].selected) out19.innerHTML = input19_1V - input19_2V;
    else if (select.options[3].selected) out19.innerHTML = input19_1V * input19_2V;
    else if (select.options[4].selected) out19.innerHTML = input19_1V / input19_2V;
    else out19.innerHTML = 'incorrect value';
}

//--------20---------

let input20_1 = document.querySelector('input[name=input20_1]'); //input[name=input20_1]
let input20_2 = document.querySelector('input[name=input20_2]'); //input[name=input20_2]
let inputList = document.querySelector('input[name=list]'); //input[name=list]
let button20 = document.querySelector('.button20'); //button20
let out20 = document.querySelector('.out20'); //поле виводу результату

button20.onclick = () => {
    let input20_1V = +input20_1.value;
    let input20_2V = +input20_2.value;
    let inputListV = inputList.value;

    switch (inputListV) {
        case '+':
            out20.innerHTML = input20_1V + '  +   ' + input20_2V + ' = ' + (input20_1V + input20_2V);
            break;
        case '-':
            out20.innerHTML = input20_1V + '  -   ' + input20_2V + ' = ' + (input20_1V - input20_2V);
            break;
        case '*':
            out20.innerHTML = input20_1V + '  *   ' + input20_2V + ' = ' + (input20_1V * input20_2V);
            break;
        case '/':
            out20.innerHTML = input20_1V + '  /   ' + input20_2V + ' = ' + (input20_1V / input20_2V);
            break;
        default:
            out20.innerHTML = 'incorrect value';
            break;
    }

    inputList.value = '';
}
