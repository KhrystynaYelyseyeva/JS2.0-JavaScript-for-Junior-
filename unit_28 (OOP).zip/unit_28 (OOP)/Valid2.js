class Valid2 extends Valid{
    constructor(email, password,isValid,emaiError="", passwordError=""){
        super(email, password,isValid);
        this.emaiError=emaiError;
        this.passwordError=passwordError;
    }

    validate() {
        if (this.password.length < 5) {
            this.passwordError = "min length 6";
        } else if (this.email == "") {
            this.emaiError = "email empty";
        }
        else {
            this.isValid = true;
        }
    }
}