class Goods2 extends Goods {
    constructor(name, amount, image, count, sale) {
        super(name, amount, image, count);
        this.sale = sale;
    }

    draw(perentElement) {
        let color = "red";
        let text = "sale";

        if (this.sale == false) {
            color = "grey";
            text = "no sale";
        }

        document.querySelector(perentElement).innerHTML = `<div>
                                                        <img src=${this.image}>
                                                        <spen>${this.name}</spen>
                                                        <spen>${this.amount}</spen>
                                                        <p style="color:${color}">${text}</p>
                                                        </div>`
    }
}