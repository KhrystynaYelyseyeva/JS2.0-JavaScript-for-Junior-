class Goods {
    constructor(name, amount, image, count) {
        this.name = name;
        this.amount = amount;
        this.image = image;
        this.count = count;
    }

    draw(perentElement) {
        document.querySelector(perentElement).innerHTML = `<div>
                                                        <img src=${this.image}>
                                                        <spen>${this.name}</spen>
                                                        <spen>${this.amount}</spen>
                                                        </div>`
    }
}
