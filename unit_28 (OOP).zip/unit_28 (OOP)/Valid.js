class Valid {
    constructor(email, password,isValid=false){
        this.email=email;
        this.password=password;
        this.isValid=isValid;
    }

    validate(){
        //let reg=new RegExp("\w+{6,}");
        //if(this.password.test(reg)) this.isValid=true;
        if (this.password.length > 5) this.isValid = true;    
    }
}