// TASK 1.  Напишите функцию func_1, которая присваивает p.u-1 ширину 200px.Проверьте ее работу.Допишите возможность присваивать высоту равную 100px;

function func_1(h = '200px') {
    return document.querySelector('.u-1').style.height = h;
};

func_1('100px');

// TASK 2. Напишите функцию func_2, которая будучи запущенной присваивает блоку p.u-2 класс css-1. Задайте данному классу через CSS зеленый цвет фона.

function func_2() {
    return document.querySelector('.u-2').classList.add('css-1');
};

func_2();

// TASK 3. Используя цикл, добавьте на все блоки p.u - 3 событие onclick.По клику запускайте функцию func_3, которая окрашивает элемент, на котором произошло событие в красный цвет фона.Для обращения внутри функции к такому элементу используйте this.
let u3 = document.querySelectorAll('.u-3');


function func_3() {
//this.style.background = 'red';
    return this.classList.add('css-5');
}

for (let i = 0, l = u3.length; i < l; i++) {
    u3[i].onclick = func_3;
}


// TASK 4. Используя цикл, добавьте на все блоки p.u - 4 событие onclick.По клику запускайте функцию func_4, которая присваивает элементу, на котором произошло событие, класс css - 2. Для обращения внутри функции к такому элементу используйте this.
let u4 = document.querySelectorAll('.u-4');


function func_4() {
    return this.classList.add('css-2');
}

for (let i = 0, l = u4.length; i < l; i++) {
    u4[i].onclick = func_4;
}


// TASK 5. C помощью цикла, повесьте на блоки p.u - 5 функцию func_5, которая при клике будет удалять класс css - 3 с элемента, на котором произошло событие.

let u5 = document.querySelectorAll('.u-5');


function func_5() {
    return this.classList.remove('css-3');
}

for (let i = 0, l = u5.length; i < l; i++) {
    u5[i].onclick = func_5;
}


// TASK 6. Есть кнопка.u - 6. Напишите функцию, которая при клике делает toggle классу.active для данной кнопки.
const button6 = document.querySelector('.u-6');

function func_6() {
    return this.classList.add('active');
}

button6.onclick = func_6;

// TASK 7. Напишите функцию func - 7, которая будучи запущенной возвращает количество элементов с классом css-3.
let css3 = document.querySelectorAll('.css-3');

function func_7() {
    return css3.length;
}

console.log('------------7------------');
console.log(func_7());

// TASK 8. Напишите функцию func - 8, которая будучи запущенной, присваивает всем элементам p.u - 1 атрибут title со значением test - data.
const u1 = document.querySelectorAll('.u-1');

function func_8() {
    let i = 0, l1 = u1.length;
    while (i < l1) {
        u1[i].setAttribute('title', 'test-data');
        i++;
    }
    return 0;
}

func_8();

// TASK 9. С помощью цикла получите кнопки.u - 9. Добавьте на них событие onclick которое запускает функцию func - 9. Функция возращает data атрибут элемента, по которому кликнули.
const buttunSet9 = document.querySelectorAll('.u-9');

for (let i = 0, l = buttunSet9.length; i < l; i++) {
    buttunSet9[i].onclick = function func_9() {
        console.log('------------9------------');
        console.log(this.getAttribute('data'));

        return this.getAttribute('data');
    }
}

// TASK 10. Напишите функцию func - 10, которая при клике на кнопке.u -10__button читает атрибут валюты data - currency и на основании этого выводит в p.u -10__out коэффициент данной валюты по отношению к доллару.Коэффициент возьмите приблизительно из интернета.Считается, что пользователь всегда вводит валюту в долларах.
let buttons10 = document.querySelectorAll('.u-10__button');
const out10 = document.querySelector('.u-10__out');

for (let i = 0, l = buttons10.length; i < l; i++) {
    buttons10[i].onclick = function func_10() {
        let currency = this.getAttribute('data-currency');
        switch (currency) {
            case 'euro':
                return out10.innerHTML = '0.92';
                break;
            case 'usd':
                return out10.innerHTML = '1';
                break;
            case 'rub':
                return out10.innerHTML = '69.58';
                break;
            default:
                return 2;
                break;

        }
    }
}

// TASK 11.Напишите функцию func - 11, которая при клике на кнопке.u -11__button читает атрибут валюты data - currency и на основании этого выводит в p.u -11__out перевод валюты введенной пользователем в input.u -11__input в указанную валюту.Считается, что пользователь всегда вводит валюту в долларах. 
const buttons11 = document.querySelectorAll('.u-11__button');
const input11 = document.querySelector('.u-11__input');
const out11 = document.querySelector('.u-11__out');

for (let i = 0, l = buttons11.length; i < l; i++) {
    let input11V = +input11.value;
    buttons11[i].onclick = function func_11() {
        let currency = this.getAttribute('data-currency');
        switch (currency) {
            case'euro':
                return out11.innerHTML = `${input11V * 0.92}`;
                break;
            case'usd':
                return out11.innerHTML = `${input11V}`;
                break;
            case'rub':
                return out11.innerHTML = `${input11V * 69.58}`;
                break;
            default:
                return 3;
                break;
        }
    }
}

// TASK  12. Создайте функцию func - 12, которая создает через createElement элемент div, присваивает ему класс css - 4 и возвращает данный элемент

function func_12() {
    let myDiv12 = document.createElement('div');
    myDiv12.classList.add('css-4');
    return myDiv12;
}

console.log('------------12-----------');
console.log(func_12());

// TASK  13.Создайте функцию func - 13, которая создает элемент span.span - 13 с текстом 13 через createElement и вставляет его в p.u - 13(append).

function func_13() {
    let p13 = document.querySelector('.u-13');

    let mySpan13 = document.createElement('span');
    mySpan13.classList.add('span-13');
    mySpan13.innerHTML = '13';
    p13.appendChild(mySpan13);

    return 0;
}

func_13();

// TASK  14. Создайте функцию func - 14, которая создает элемент span.span - 14 с текстом 14 через createElement и вставляет его в p.u - 14(prepend).

function func_14() {
    let p14 = document.querySelector('.u-14');

    let mySpan14 = document.createElement('span');
    mySpan14.classList.add('span-14');
    mySpan14.innerText = '14';
    p14.prepend(mySpan14);

    return 0;
}

func_14();

// TASK 15. Создайте функцию func - 15, которая создает элемент span.span - 15 с текстом 15 через createElement и вставляет его в p.u - 15(before)

function func_15() {
    let mySpan15 = document.createElement('span');
    mySpan15.innerHTML = '15';
    mySpan15.classList.add('span-15');
    document.querySelector('.u-15').before(mySpan15);

    return 0;
}

func_15();

// TASK    16. Создайте функцию funct - 16, которая создает элемент button.u - 16 c текстом Push.Повесьте на данный элемент событие onclick со стрелочной функцией, которая в консоль выводит текст u - 16. И после добавления события добавьте данный элемент на страницу в div.u -16__out.Проверьте работоспособность события.

function func_16() {
    let myButton16 = document.createElement("button");
    myButton16.innerHTML = 'PUSH';
    myButton16.classList.add('u-16');

    myButton16.onclick = () => console.log('u-16');

    document.querySelector('.u-16__out').prepend(myButton16);

    return 0;
}

func_16();

// TASK 17. Создайте функцию, funct - 17, которая при запуске создаст элемент p c текстом 17 и заменит этим элементом div.u - 17

function func_17() {
    let div17 = document.querySelector('.u-17');
    let myP17 = document.createElement('p');
    myP17.innerHTML = '17';

    div17.parentNode.replaceChild(myP17, div17);

    return 0;
}

func_17();

// TASK 19. C помощью цикла повесьте на div.out - 18 функцию func - 18. Данная функция дожна удалять элемент, на котором произошел клик из DOM.Функция должна возвращать удаленный элемент
let divs18 = document.querySelectorAll('.out-18');

for (let i = 0, l = divs18.length; i < l; i++) {
    divs18[i].onclick = function func_18() {
        this.remove();
        return this;
    }
}

// TASK   19. Создайте функцию func - 19, которая принимает параметр текст.Создает элемент li, вставляет в него указанный текст, и добавляет на страницу в ul.u - 19 в конец списка.

function func_19(text) {
    let myLi19 = document.createElement('li');
    myLi19.innerHTML = text;
    document.querySelector('.u-19').append(myLi19);

    return 0;
}

func_19('Second');

// TASK 20. Доработайте предыдущее задание.Допишите функцию func - 20 которая может принимать текст от пользователя и вставлять в список ul.u - 20. Также добавьте checkbox - важное, при этом созданный li получает класс.css - 5.
let button20 = document.querySelector('.but-20');
let input20 = document.querySelector('.inp-20');

function func_20(text) {
    let checkbox20 = document.querySelector('input[type=checkbox]');

    let myLi20 = document.createElement('li');
    myLi20.innerHTML = text;

    if (checkbox20.checked) myLi20.classList.add('css-5');

    document.querySelector('.u-20').append(myLi20);
    return 0;
}

button20.onclick = function (){func_20(input20.value)};




