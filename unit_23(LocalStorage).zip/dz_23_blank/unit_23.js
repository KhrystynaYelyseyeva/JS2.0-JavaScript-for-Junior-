// Task 1 ============================================
/* Создайте функцию t1 которая записывает  в LS  ключ 5 со значением 11. Проверьте что происходит при повторном вызове функции. Запускается ф-я по кнопкуе b-1. */

function t1() {
    localStorage.setItem('5', 11);
}

document.querySelector('.b-1').onclick = t1;

// Task 2 ============================================
/* Создайте функцию t2 которая записывает  в LS  массив a2 = [7,6,5]. Ключ a2. Проверьте что происходит при повторном вызове функции. Запускается ф-я по кнопкуе b-2. */

function t2() {
    localStorage.setItem('a2', JSON.stringify([7, 6, 5]));
}

document.querySelector('.b-2').onclick = t2;


// Task 3 ============================================
/*  При нажатии кнопки t3 выведите из LS сохранненный массив a2. Выведите в out-3 в формате ключ пробел значение перенос строки.  */

function t3() {
    let a2 = JSON.parse(localStorage.getItem('a2'));
    a2.map((item, key) => document.querySelector('.out-3').innerHTML += `${key} ${item}<br>`);
}

document.querySelector('.b-3').onclick = t3;

// Task 4 ============================================
/*  Создайте функцию t4 которая записывает  в LS  массив a4 = {hello: world, hi:mahai}. Ключ a4. Проверьте что происходит при повторном вызове функции. Запускается ф-я по кнопкуе b-4.*/

function t4() {
    localStorage.setItem('a4', JSON.stringify({hello: 'world', hi: 'mahai'}));
}

document.querySelector('.b-4').onclick = t4;

// Task 5 ============================================
/*   При нажатии кнопки t5 выведите из LS сохранненный массив a4. Выведите в out-5 в формате ключ пробел значение перенос строки. */

function t5() {
    let a5 = JSON.parse(localStorage.getItem('a4'));
    for (let key in a5) document.querySelector('.out-5').innerHTML += `${key} ${a5[key]}<br>`;
}

document.querySelector('.b-5').onclick = t5;

// Task 6 ============================================
/*  Создайте функцию t6 которая очищает весь LS. Запуск по кнопке b-6*/

function t6() {
    localStorage.clear();
}

document.querySelector('.b-6').onclick = t6;


// Task 7 ============================================
/*  Создайте input i-7 куда пользователь может вводить числа и строки. Создайте массив a7. Когда пользователь нажимает кнопку b-7 число должно добавляться в массив. Массив должен сохраняться в LS с ключем a7.*/
let a7 = [];

function t7() {
    let value = document.querySelector('.i-7').value;

    let regex = /^\d+(?![A-Za-z])/g;
    if (regex.test(value)) value = +value;

    a7.push(value);

    localStorage.setItem('a7', a7);
}

document.querySelector('.b-7').onclick = t7;

// Task 8 ============================================
/*   Создайте функцию t8 при запуске которой из a7 удаляется последний элемент. После чего массив сохраняется в LS с ключем a7. Использовать массив из предыдущего задания. */

function t8() {
    localStorage.setItem('a7', a7.pop());
}

document.querySelector('.b-8').onclick = t8;


// Task 9 ============================================
/* Создайте 3 radiobutton c именем rb-9. Задайте для каждого value: #fff, #c0c0c0, #555. При изменении radibutton записывайте значение value в LS с ключем bg. Добавьте слушатель событий на изменение LS. Если есть ключ bg то при наступлении события изменять цвет фона на заданный в LS. */
let radio = document.querySelectorAll('input[name="rb-9"]');

function t9() {
    for (let item of radio) {
        if (item.checked) return localStorage.setItem('bg', item.value);
    }
}

for (let item of radio) {
    item.onclick = function () {
        t9()
    };
}


// Task 10 ============================================
/*  Проект. Дана переменная card - корзина. Добавьте кнопку b-10 и функцию t10, которые сохраняют card в LS.*/

const card = {
    'apple': 3,
    'grape': 2
}

function t10() {
    localStorage.setItem('card', JSON.stringify(card));
}

document.querySelector('.b-10').onclick = () => {
    document.querySelector('.message').remove();
    t10();
    t11();
    document.querySelector('.b-10').remove();
};

// Task 11 ============================================
/*  Создайте фукнцию t11 которая читает корзину из LS и выводит на страницу в виде таблицы. Формат -  название товара - количество. Функция должна вызываться всегда после перезаписи LS ( в данном случае - просто добавьте ее вызов в нужные функции). */

function t11() {
    let basket = JSON.parse(localStorage.getItem("card"));

    let table = document.createElement('TABLE');
    let tbdy = document.createElement('TBODY');
    document.querySelector('.out-10').appendChild(table);

    let sum = 0;

    for (let key in basket) {
        tbdy.insertRow();

        for (let j = 0; j < 3; j++) {
            let td = tbdy.appendChild(document.createElement('TD'));
            if (j == 0) td.innerHTML = `<spen>${key}</spen>`;
            if (j == 1) t12(key).forEach(button => td.appendChild(button));
            if (j == 2) td.innerHTML = `<spen>${basket[key]}</spen>`;
        }

        sum += basket[key];
    }

    table.appendChild(tbdy);

    t13(sum);
}


// Task 12 ============================================
/*  Добавьте в таблицу кнопки плюс и минус возле каждого товара. При нажатии кнопки - изменяйте количество товаров в card, обновляйте LS, выводите на страницу. */

function t12(key) {
    let add = document.createElement('BUTTON');
    add.classList.add("button-primary");
    add.innerText = "+";
    add.onclick = () => {
        card[key]++;
        localStorage.clear();
        t10();
        document.querySelector("table").remove();
        t11();
    }

    let del = document.createElement('BUTTON');
    del.classList.add("button-primary");
    del.innerText = "-";
    del.onclick = () => {
        if (card[key] > 0) {
            card[key]--;
            localStorage.clear();
            t10();
            document.querySelector("table").remove();
            t11();
        }
    }

    return [add, del];
}


// Task 13 ============================================
/*  Добавьте в таблицу footer который считает общее количество товара. */

function t13(sum) {
    let footer = document.querySelector("tbody").appendChild(document.createElement('TR'));

    for (let i = 0; i < 2; i++) {
        let td = footer.appendChild(document.createElement('TD'));
        if (i == 0) {
            td.setAttribute('colspan', '2');
            td.innerHTML = `<spen>SUM</spen>`;
        }
        if (i == 1) td.innerHTML = `<spen>${sum}</spen>`;
    }
}

// Task 14 ============================================
/*  Добавьте функцию t14, которая при загрузке страницы проверяет наличие card в LS и если есть -выводит его на страницу. Если нет - пишет корзина пуста. */

function t14() {
    if (localStorage.length != 0) {
        t10();
        t11();
        document.querySelector('.b-10').remove();
    } else {
        document.querySelector('.out-10').innerHTML = `<spen class="message">Kорзина пуста</spen>`;
    }
}

t14();