//--------1----------
console.log('Kristina');

//--------2----------
console.log(1);

//--------3----------
console.log('Добро '+'пожаловать '+' на курс');

//--------4----------
//alert(2019);

//--------5----------
//alert(2019-200);

//--------6----------
document.getElementById('one').innerHTML = 'Hello World';

//--------7----------
document.getElementById('two').innerHTML = 12*12;

//--------8----------
document.querySelector('.one').innerHTML = 'Hello World';

//--------9----------
document.querySelector('h2>span').innerHTML = 'world';

//--------10---------
document.querySelector('.three').innerHTML ='<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab asperiores at consequuntur corporis cum dicta ducimus eaque facere facilis minima molestiae natus non omnis placeat possimus, quibusdam quidem repellat sunt!</h3>';

//--------11---------
document.querySelector('.four').innerHTML +='<h4>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab asperiores at consequuntur corporis cum dicta ducimus eaque facere facilis minima molestiae natus non omnis placeat possimus, quibusdam quidem repellat sunt!</h4><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab asperiores at consequuntur corporis cum dicta ducimus eaque facere facilis minima molestiae natus non omnis placeat possimus, quibusdam quidem repellat sunt!</p>';

//--------12---------
let a = document.querySelector('.five');
a.innerHTML = 3.1415;

//--------13---------
let div7 = document.querySelector('.seven');
div7.innerHTML = '<img src="https://cdn4.iconfinder.com/data/icons/food-and-drink-flat-gradient/32/cone_ice_cream_food_drink_sweet-512.png" alt="">';

//--------14---------
let multi = document.querySelector('.multiplication'), z1 = 6, z2 = 3;
multi.innerHTML = z1 * z2;

//--------15---------
let divis = document.querySelector('.division'), y1 = 6, y2 = 3;
divis.innerHTML = y1 / y2;

//--------16---------
let sum = document.querySelector('.sum'), x1='Hello', x2 = 5;
divis.innerHTML = x1 + x2;

//--------17---------
let d1 = document.querySelector('.test-1');
console.log(d1);

//--------18---------
let d2 = document.querySelector('.test-2');
console.log(d2);
d2 = 5;
console.log(d2);

//--------19---------
let divS3 = document.querySelector('.s3');
console.log(divS3);
divS3 = document.querySelector('.s4');
console.log(divS3);

//--------20---------
//document.querySelector('body').innerHTML = '';