//--------1----------
let set1 = new Set();
set1.add(3);
console.log(set1);

//--------2----------
let input2 = document.querySelector('.inp-2');
let button2 = document.querySelector('.but-2');

button2.onclick = () => {
    set1.add(input2.value);
    console.log(set1)
}

//--------3----------
let input3 = document.querySelector('.inp-3');
let button3 = document.querySelector('.but-3');

button3.onclick = () => {
    let input3V = input3.value;
    if (set1.has(input3V)) {
        set1.delete(input3V);
        console.log(set1);
    } else alert('Err');
}
//--------4----------
let input4 = document.querySelector('.inp-4');
let button4 = document.querySelector('.but-4');

function t4(v) {
    return set1.has(v);
}

button4.onclick = () => {
    console.log(t4(input4.value));
}

//--------5----------
let out5 = document.querySelector('.out-5');

function t5() {
    return set1.size;
}

out5.textContent = t5();
//--------6----------
let out6 = document.querySelector('.out-6');
let a6 = [3, 4, 3, 2, 4, 56, 1, 23];

function t6() {
    let set6 = new Set(a6);
    return set6;
}

out6.textContent = t6().size;
//--------7----------
let input7 = document.querySelector('.inp-7');
let button7 = document.querySelector('.but-7');

button7.onclick = () => {
    let a7 = input7.value.split('');
    let s7 = new Set(a7);
    if (a7.length != s7.size) alert('Enter only unique symbols.');
}

//--------8----------
let out8 = document.querySelector('.out-8');
let button8 = document.querySelector('.but-8');

let s8 = new Set([0, 1, 'f', true]);

function t8(s = new Set()) {
    let a8 = Array.from(s), a8_res = [];
    for (let i = 0, l = a8.length; i < l; i++) {
        if (i % 2 != 0) a8_res.push(a8[i]);
    }
    return a8_res;
}

button8.onclick = () => {
    out8.textContent = t8(s8);
}

//--------9----------
let out9 = document.querySelector('.out-9');

let a9 = new Set([1, 2, 3, 4, 5]);

function t9(s = new Set()) {
    let a9_res = Array.from(s).reverse();
    return a9_res;
}

out9.textContent = t9(a9);

//--------10---------
let a10 = [1, 1, 1, 1, 2, 2, 2, 3, 4, 4, 5, 5, 5, 5, 5, 5];
let a10_res = {0: 0,}//{}; або new Object(); не спрацьовує.Чому?
let s10 = new Set(a10);

for (let key in a10_res) {
    for (let item of s10) {
        key = item;
        a10_res[key] = 0;
        for (let i = 0, l = a10.length; i < l; i++) {
            if (key == a10[i]) a10_res[key]++;
        }
    }
}

console.log(a10_res);

//--------11---------
let out11 = document.querySelector('.out-11');
let button11 = document.querySelector('.b-11');
let input11 = document.querySelector('.i-11');

let a11_res = [];

function t11(item = '') {
    a11_res = new Set(a11_res);
    a11_res.add(item);
    return a11_res = Array.from(a11_res);
}

button11.onclick = () => {
    out11.textContent = t11(input11.value);
}

//--------12---------
let out12 = document.querySelector('.out-12');
let button12 = document.querySelector('.b-12');

function t12(s = new Set()) {
    let a12_res = Array.from(s);
    return a12_res;
}

out12.textContent = t12([1, 2, 3, 4, 5]);

//--------13---------
let out13 = document.querySelector('.out-13');
let button13 = document.querySelector('.u13-reverse');

function t13(s = new Set(), e = document.querySelector('.out13')) {
    for (let item of s) {
        e.innerHTML += `${item},`
    }
    ;
    return 0;
}

t13([2, 4, 6, 'a', 'b', 'c'], out13);

//--------14---------
let out14 = document.querySelector('.out-14');

function t14(s = new Set(), e = document.querySelector('.out14'), r = "-") {
    for (let item of s) {
        e.innerHTML += `${item}${r}`;
    }
    ;
    return 0;
};

t14([1, 2, 3], out14);

//--------15---------
let out15 = document.querySelector('.out-15');

let arr15 = [[1, 0], [1, 0], [2, 0]];

function t15(a = []) {
    let a15_res = new Set(a);
    for (let item of a15_res) {
        out15.textContent += item + '; ';
    }
    return 0;
}

t15(arr15);

//--------16---------
let a16 = [{Ivan: 1}, {Ivan: 1}, {Ivan: 2}, {Serg: 0}];

function t16(a = []) {
    let a16_res = new Set(a);
    console.log(a16_res);
    for (let i of a16_res) {
        console.log(i);
    }
    return a16_res;
}

t16(a16);

//--------17---------
let out17 = document.querySelector('.out-17');

let u17 = 'Primer';

function t17() {
    let s17 = new Set(u17);
    console.log(s17);
    return 0;
}

t17();

//--------18---------
let out18 = document.querySelector('.out-18');

let a18 = [5, 7, 9, 11, 13, 15];


function t18() {
    let k = 0;

    for (let i of a18) {
        let a18_res = `${k}-${i}<br>`;
        out18.innerHTML += a18_res;
        k++;
    }
    return 0;
}

t18();

//--------19---------
let out19 = document.querySelector('.out-19');

let a19 = new Set([1, 2, 3, 4, 5, 6]);

function t19() {
    a19 = Array.from(a19);
    for (let i = 0, l = a19.length; i < l; i++) {
        if (i % 2 != 0) out19.innerHTML += a19[i] + " ";
    }
    return 0;
}

t19();

//--------20---------
let out20 = document.querySelector('.out-20');

function t20(a = []) {
    let s20_res = new Set(), s21_res = new Set();
    for (let i = 0, l = a.length; i < l; i++) {
        if (i % 2 == 0) s20_res.add(a[i]);
        else s21_res.add(a[i]);
    }
    console.log(s20_res);
    console.log(s21_res);
    return 0;
}

t20([0, 1, 2, 3, 4, 5]);