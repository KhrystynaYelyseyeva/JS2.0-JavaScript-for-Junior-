//--------1----------
let out1 = document.querySelector('.out-1');
const a1 = {
    3: 'hello',
    'one': 'hi'
};

for (let key in a1) {
    out1.innerHTML += `${key}: ${a1[key]}<br>`;
}

//--------2----------
let out2 = document.querySelector('.out-2');
let a2 = {
    3: 'hello',
    'one': 'hi',
    'testt': 'vodoley',
    'ivan': 'ivanov'
};

for (let key in a2) {
    if (a2[key].length > 3) out2.innerHTML += `${a2[key]}<br>`;
}

//--------3----------
let out3 = document.querySelector('.out-3');
let a3 = {
    3: 'hello',
    'one': 'hi',
    'testt': 'vodoley',
    'ivan': 'ivanov'
};

for (let key in a3) {
    if (key.length > 3) out3.innerHTML += `${a3[key]}<br>`;
}

//--------4----------
let out4 = document.querySelector('.out-4');
let a4 = {
    3: 'hello',
    'one': 4,
    'testt': 'vodoley',
    'ivan': 6
};

for (let key in a4) {
    if (isFinite(a4[key])) out4.innerHTML += `${a4[key]}<br>`;
}

//--------5----------
let out5 = document.querySelector('.out-5');
let a5 = {
    a: 7,
    z: 4,
    45: 12,
    f: 6
};
let sum5 = 0;
for (let key in a5) {
    sum5 += a5[key];
    out5.innerHTML = `${sum5}`
}

//--------6----------
let out6 = document.querySelector('.out-6');
let a6 = {
    name: 'Kristina',
    age: 28,
    sex: 'woman',
    height: 156,
    marvel: 'Doctor Strange'
};

for (let key in a6) {
    out6.innerHTML += `${key}: ${a6[key]}<br>`;
}

//--------7----------
let out7 = document.querySelector('.out-7');
let inputKey = document.querySelector('.u7-key__input');
let inputVal = document.querySelector('.u7-value__input');
let button7 = document.querySelector('.but-7');
let a7 = {};

button7.onclick = () => {
    let inputKeyV = inputKey.value;
    let inputValV = inputVal.value;

    a7[inputKeyV] = inputValV;
    for (let key in a7) out7.innerHTML += `${key}: ${a7[key]}<br>`;

}

//--------8----------
let out8 = document.querySelector('.out-8');
let inputRemove = document.querySelector('.u8-key__input');
let button8 = document.querySelector('.but-8');

button8.onclick = () => {
    let inputRemV = inputRemove.value;

    delete a7[inputRemV];
    for (let key in a7) out8.innerHTML = `${key}: ${a7[key]}<br>`;
}
//--------9----------
let out9 = document.querySelector('.out-9');
let inputDelete = document.querySelector('.u9-delete-value__input');
let button9 = document.querySelector('.but-9');

button9.onclick = () => {
    for (let key in a7) {
        if (a7[key] == inputDelete.value) {
            delete a7[key];
        }
    }
    for (let key in a7) out9.innerHTML = `${key}: ${a7[key]}<br>`;
}

//--------10---------
let out10 = document.querySelector('.out-10');
let inputFind = document.querySelector('.u10-has-key__input');
let button10 = document.querySelector('.but-10');

button10.onclick = () => {
    for (let key in a7) {
        if (key == inputFind.value) out10.innerHTML = true;
        else out10.innerHTML = false;
    }
}

//--------11---------
let out11 = document.querySelector('.out-11');
let a11 = {
    "red": ['Академмістечко', 'Житомирська', 'Святошин', 'Нивки', 'Берестейська', 'Шулявська', 'Політехнічний інститут', 'Вокзальна', 'Університет', 'Театральна', 'Хрещатик', 'Арсенальна', 'Дніпро', 'Гідропарк', 'Лівобережна', 'Дарниця', 'Чернігівська', 'Лісова'],
    "green": ['Сирець', 'Дорогожичі', 'Лукянівська', 'Золоті Ворота', 'Палац спорту', 'Кловська', 'Печерська', 'Дружба народів', 'Видубичі', 'Славутич', 'Осокорки', 'Позняки', 'Харківська', 'Вирлиця', 'Бориспільська', 'Червоний Хутір'],
    "blue": ['Героїв Дніпра', 'Мінська', 'Оболонь', 'Почайна', 'Тараса Шевченка', 'Контрактова площа', 'Поштова площа', 'Майдан Незалежності', 'Площа Льва Толстого', 'Олімпійська', 'Палац Україна', 'Либідська', 'Деміївська', 'Голосіївська', 'Васильківська', 'Виставковий центр', 'Іподром', 'Теремки']
}
for (let key in a11) out11.innerHTML += `${key}: ${a11[key]}<br><hr>`;

//--------12---------
let out12 = document.querySelector('.out-12');
let select12 = document.querySelector('.u12-branch');
let button12 = document.querySelector('.but-12');

button12.onclick = () => {
    switch (select12.value) {
        case 'red':
            out12.innerHTML = `${a11['red']}`;
            break;
        case 'green':
            out12.innerHTML = `${a11['green']}`;
            break;
        case 'blue':
            out12.innerHTML = `${a11['blue']}`;
            break;
    }
}

//--------13---------
let out13 = document.querySelector('.out-13');
let button13 = document.querySelector('.u13-reverse');

button13.onclick = () => {
    switch (select12.value) {
        case 'red':
            out13.innerHTML = `${a11['red'].reverse()}`;
            break;
        case 'green':
            out13.innerHTML = `${a11['green'].reverse()}`;
            break;
        case 'blue':
            out13.innerHTML = `${a11['blue'].reverse()}`;
            break;
    }
}

//--------14---------
let out14 = document.querySelector('.out-14');
let select14 = document.querySelector('.u14-find-station');
let button14 = document.querySelector('.but-14');

button14.onclick = () => {
    for (let key in a11) if (a11[key].includes(select14.value)) out14.innerHTML = `${key}`;
}

//--------15---------
let out15 = document.querySelector('.out-15');
let select15_1 = document.querySelector('.first_station');
let select15_2 = document.querySelector('.second_station');
let button15 = document.querySelector('.but-15');

button15.onclick = () => {
    let st1 = select15_1.value;
    let st2 = select15_2.value;
    for (let key in a11) {
        if (a11[key].includes(st1) && a11[key].includes(st2)) out15.innerHTML = `Вам потрібно проїхати ${Math.abs((a11[key].indexOf(st1) - a11[key].indexOf(st2))) - 1} станції.`;
        //else out15.innerHTML = `Будь ласка, виберіть станції, що знаходятьсяя на одній гілці.`;//якщо розкоментувати else не працює коректно
    }
}

//--------16---------
let button16 = document.querySelector('.but-16');
let select16 = document.querySelector('.u16-select');
let radio16 = document.querySelectorAll('.u16-radio');

function createStations(key) {
    for (let i = 0, l = a11[key].length; i < l; i++) {
        //створюється option
        let option = document.createElement('option');
        //перебираємо масив і видаляємо всі пробіли
        let optionValue = a11[key][i].replace(/\s+/g, '');
        //додаємо атрибут value із значенням з масива
        option.setAttribute(`${optionValue}`, 'value');
        //додаємо текст у option
        option.innerHTML = `${a11[key][i]}`;
        //додаємо option у select
        select16.appendChild(option);
    }
    return 0;
}

button16.onclick = () => {
    for (let i = select16.options.length - 1; i >= 0; i--) select16.remove(i);//видаляємо попередній вивід
    for (let i = 0, l = radio16.length; i < l; i++) if (radio16[i].checked) createStations(`${radio16[i].value}`);
}

//--------17---------
let out17 = document.querySelector('.out-17');
let a17 = {
    "red": [['Академмістечко', 0], ['Житомирська', 0], ['Святошин', 0], ['Нивки', 0], ['Берестейська', 0], ['Шулявська', 0], ['Політехнічний інститут', 0], ['Вокзальна', 0], ['Університет', 0], ['Театральна', 1], ['Хрещатик', 1], ['Арсенальна', 0], ['Дніпро', 0], ['Гідропарк', 0], ['Лівобережна', 0], ['Дарниця', 0], ['Чернігівська', 0], ['Лісова', 0]],
    "green": [['Сирець', 0], ['Дорогожичі', 0], ['Лукянівська', 0], ['Золоті Ворота', 1], ['Палац спорту', 1], ['Кловська', 0], ['Печерська', 0], ['Дружба народів', 0], ['Видубичі', 0], ['Славутич', 0], ['Осокорки', 0], ['Позняки', 0], ['Харківська', 0], ['Вирлиця', 0], ['Бориспільська', 0], ['Червоний Хутір', 0]],
    "blue": [['Героїв Дніпра', 0], ['Мінська', 0], ['Оболонь', 0], ['Почайна', 0], ['Тараса Шевченка', 0], ['Контрактова площа', 0], ['Поштова площа', 0], ['Майдан Незалежності', 1], ['Площа Льва Толстого', 1], ['Олімпійська', 0], ['Палац Україна', 0], ['Либідська', 0], ['Деміївська', 0], ['Голосіївська', 0], ['Васильківська', 0], ['Виставковий центр', 0], ['Іподром', 0], ['Теремки', 0]]
}
for (let key in a17) out17.innerHTML += `${a17[key]}<hr>`;

//--------18---------
let out18 = document.querySelector('.out-18');
for (let key in a17) {
    for (let i = 0, h = a17[key].length; i < h; i++) if (a17[key][i][1] == 1) out18.innerHTML += `${a17[key][i][0]}<br>`;
}

//--------19---------
let out19 = document.querySelector('.out-19');
let asia = {
    "Afghanistan": {"city": 'Kabul', "population": 35530081, "area": 652090.00},
    "Armenia": {"city": 'Yerevan', "population": 2930450, "area": 29800.00},
    "Azerbaijan": {"city": 'Baku', "population": 9827589, "area": 86600.00},
    "Bahrain": {"city": 'al-Manama', "population": 1492584, "area": 694.00},
    "Bangladesh": {"city": 'Dhaka', "population": 164669751, "area": 143998.00},
    "Bhutan": {"city": 'Thimphu', "population": 807610, "area": 47000.00},
    "Brunei": {"city": 'Bandar Seri Begawan', "population": 428697, "area": 5765.00},
    "Cambodia": {"city": 'Phnom Penh', "population": 16005373, "area": 181035.00},
    "China": {"city": 'Peking', "population": 1409517397, "area": 9572900.00},
    "Cyprus": {"city": 'Nicosia', "population": 1179551, "area": 9251.00},
    "Georgia": {"city": 'Tbilisi', "population": 3912061, "area": 69700.00},
    "Hong Kong": {"city": 'Victoria', "population": 7364883, "area": 1075.00},
    "India": {"city": 'New Delhi', "population": 1339180127, "area": 3287263.00},
    "Indonesia": {"city": 'Jakarta', "population": 263991379, "area": 1904569.00},
    "Iran": {"city": 'Tehran', "population": 81162788, "area": 1648195.00},
    "Iraq": {"city": 'Baghdad', "population": 38274618, "area": 1648195.00},
    "Israel": {"city": 'Jerusalem', "population": 8321570, "area": 21056.00},
    "Japan": {"city": 'Tokyo', "population": 127484450, "area": 377829.00},
    "Jordan": {"city": 'Amman', "population": 9702353, "area": 88946.00},
    "Kuwait": {"city": 'Kuwait', "population": 4136528, "area": 17818.00},
    "Kyrgyzstan": {"city": 'Bishkek', "population": 35530081, "area": 199900.00},
    "Laos": {"city": 'Vientiane', "population": 6858160, "area": 236800.00},
    "Lebanon": {"city": 'Beirut', "population": 6082357, "area": 10400.00},
    "Macao": {"city": 'Macao', "population": 473000, "area": 18.00},
    "Malaysia": {"city": 'Kuala Lumpur', "population": 31624264, "area": 329758.00},
};
for (let key in asia) {
    out19.innerHTML += `<strong>${key}</strong>:<br><ul>`;

    for (let k in asia[key]) {
        out19.innerHTML += `<li>${k}: ${asia[key][k]}</li>`;
    }

    out19.innerHTML += `</ul><hr>`;
}
//--------20---------
let out20 = document.querySelector('.out-20');
let select20 = document.querySelector('.select-20');

for (let key in asia) {
    let option = document.createElement("option");
    let selectValue = key.replace(/\s+/g, '_');
    option.setAttribute(`${selectValue}`, 'value');
    option.innerHTML = `${key}`;
    select20.appendChild(option);
}


select20.onchange = () => {

    for (let i = 0, l = select20.options.length; i < l; i++) {
        if (select20[i].selected) {
            let selectValueToKey = select20[i].value.replace(/\s+/g, ' ');
            out20.innerHTML = `<b>${selectValueToKey}</b>:<br><ul>`;
            for (let key in asia[selectValueToKey]) {
                out20.innerHTML += `<li><i>${key}</i>: ${asia[selectValueToKey][key]};</li>`;
            }
            out20.innerHTML += `</ul>`;
        }
    }
}
