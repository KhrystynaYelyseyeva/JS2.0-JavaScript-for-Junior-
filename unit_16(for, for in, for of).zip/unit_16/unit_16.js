//--------1----------
let out1 = document.querySelector(".out-1");
let button1 = document.querySelector(".b-1");
let a1 = [5, 7, 9, 11, 13, 15];

function t1() {
    for (let i of a1) {
        out1.textContent += i + ' ';
    }
    return 0;
}

button1.onclick = () => t1();

//--------2----------
let out2 = document.querySelector(".out-2");
let button2 = document.querySelector(".b-2");
let a2 = [5, 7, 9, 11, 13, 15];
let a2_res = {0: 0};

function t2() {
    for (let key in a2_res) {
        for (let i = 0, l = a2.length; i < l; i++) {
            key = i;
            a2_res[key] = a2[i];
            out2.innerHTML += `${key} - ${a2_res[key]}<br>`;
        }
    }
    return 0;
}

button1.onclick = () => t2();
//--------3----------
let d3 = document.getElementsByClassName("u-3");
let button3 = document.querySelector('.b-3');

function t3() {
    for (let i = 0, l = d3.length; i < l; i++) {
        d3[i].textContent = 3;
    }
    return 0;
}

button3.onclick = () => t3();

//--------4----------
let d4 = document.querySelectorAll(".u-3");
let button4 = document.querySelector('.b-4');

function t4() {
    for (let i = 0, l = d4.length; i < l; i++) {
        d4[i].textContent = 4;
    }
    return 0;
}

button4.onclick = () => t4();

//--------5----------
let button5 = document.querySelector('.b-5');
let div = document.createElement("div");

function t5() {
    d3.push(div);
    //у закоментованій частині нижче кодь який вирішує апрблему
    /*div.classList.add('u-3');
    document.querySelector(".j").appendChild(div);
    console.log(d3);*/
    return 0;
}

button5.onclick = () => t5();
//у консолі отримала помилку d3.push is not a function

//--------6----------
let button6 = document.querySelector('.b-6');

function t6() {
    d4.push(div);
    console.log(d4);
    return 0;
}

button6.onclick = () => t6();
//у консолі отримала помилку d4.push is not a function

//--------7----------
let button7 = document.querySelector('.b-7');
let out7 = document.querySelector('.out-7');
let a7 = [[1, 2], [3, 4], [5, 6]];

function t7() {
    let a7_res = [];
    for (let item of a7) {
        for (let i = 0, l = item.length; i < l; i++) {
            a7_res.push(item[i]);
        }
    }
    return a7_res;
}

button7.onclick = () => out7.textContent = t7();

//--------8----------
let out8 = document.querySelector('.out-8');
let button8 = document.querySelector('.b-8');

let a8 = [[1, 2, 3], [3, 4, 9], [5, 6]];

function t8() {
    let a8_res = 0;
    for (let item of a8) {
        if (item.length > a8_res) a8_res = item.length;
    }
    return a8_res;
}

button8.onclick = () => out8.textContent = t8();

//--------9----------
let button9 = document.querySelector('.b-9');

let a9 = [4, 6, 9, "hello"], a9_1 = {4: 0,};

function t9() {
    for (let item of a9) {
        a9_1[item] = item;
    }
    return a9_1;
}

button9.onclick = () => console.log(t9());

//--------10---------
let out10 = document.querySelector('.out-10');
let button10 = document.querySelector('.b-10');

let a10 = [5, 7, 9, 11, 13, 15];

function t10() {
    for (let key in a10) {
        out10.textContent += a10[key] + ' ';
    }
    return 0;
}

button10.onclick = () => t10();

//--------11---------
let out11 = document.querySelector('.out-11');
let button11 = document.querySelector('.b-11');

let a11 = [5, 7, 9, 11, 13, 15];

function t11() {
    for (let key in a11) {
        out11.innerHTML += `${key}-${a11[key]}<br>`;
    }
    return 0;
}

button11.onclick = () => t11();
//--------12---------
let div12 = document.getElementsByClassName('u-12');
let button12 = document.querySelector('.b-12');

function t12() {
    for (let key in div12) {
        div12[key].innerHTML = 12;
    }
    return 0;
}

button12.onclick = () => t12();
//--------13---------
let div13 = document.querySelectorAll('.u-13');
let button13 = document.querySelector('.b-13');

function t13() {
    for (let key in div13) {
        div13[key].innerHTML = 13;
    }
    return 0;
}

button13.onclick = () => t13();
//--------14---------
let out14 = document.querySelector('.out-14');
let button14 = document.querySelector('.b-14');

let a14 = [[1, 2], [3, 4], [5, 6]];

function t14() {
    let a14_res = [];
    for (let key in a14) {
        for (let k in a14[key]) {
            a14_res.push(a14[key][k]);
        }
    }
    return a14_res;
};

button14.onclick = () => out14.textContent = t14();

//--------15---------
let out15 = document.querySelector('.out-15');
let button15 = document.querySelector('.b-15');

let a15 = [[1, 2, 3], [3, 4, 9], [5, 6]];

function t15() {
    let a15_res = 0;
    for (let key in a15) {
        (a15[key].length > a15_res) ? a15_res = a15[key].length : a15_res = a15_res;
    }
    return a15_res;
}

button15.onclick = () => out15.innerHTML = t15();

//--------16---------
let button16 = document.querySelector('.b-16');

let a16 = [4, 6, 9, "hello"];

function t16() {
    let a16_res = {4: 0};
    for (let key in a16) {
        a16_res[a16[key]] = a16[key];
    }
    return a16_res;
}

button16.onclick = () => console.log(t16());

//--------17---------
let out17 = document.querySelector('.out-17');
let button17 = document.querySelector('.b-17');

let a17 = [5, 7, 9, 11, 13, 15];

function t17() {
    for (let item of a17) {
        out17.textContent += `${item} `
    }
    return 0;
}

button17.onclick = () => t17();

//--------18---------
let out18 = document.querySelector('.out-18');
let button18 = document.querySelector('.b-18');

let a18 = [5, 7, 9, 11, 13, 15];

function t18() {
    let k = 0;

    for (let i of a18) {
        let a18_res = `${k}-${i}<br>`;
        out18.innerHTML += a18_res;
        k++;
    }
    return 0;
}

button18.onclick = () => t18();

//--------19---------
let div19 = document.querySelectorAll('.u-19');
let button19 = document.querySelector('.b-19');

function t19() {
    for (let i of div19) {
        i.innerHTML = 19;
    }
    return 0;
}

button19.onclick = () => t19();

//--------20---------
let button20 = document.querySelector('.b-20');

let a20 = [4, 6, 9, "hello"];

function t20() {
    let a20_res = {4: 0};
    for (let i of a20) {
        a20_res[i] = i;
    }
    return a20_res;
}

button20.onclick = () => console.log(t20());