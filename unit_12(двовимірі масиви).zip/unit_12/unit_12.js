//--------1----------
let out1 = document.querySelector('.out-1');
const a = [
    [1, 2, 3],
    ['a', 'b', 'c'],
    [4, 5, 6],
    ['d', 'e', 'f'],
    [7, 8, 9],
];

for (let i = 0, h = a.length; i < h; i++) {
    for (let k = 0, l = a[i].length; k < l; k++) {
        out1.innerHTML += `${a[i][k]} `;
    }
    out1.innerHTML += '<br>';
}

//--------2----------
document.querySelector('.out-2').innerHTML = a[0][2];

//--------3----------
document.querySelector('.out-3').innerHTML = a[3][a[3].indexOf('e')];

//--------4----------
document.querySelector('.out-4').innerHTML = a[2];

//--------5----------
for (let i = 0, l = a.length; i < l; i++) document.querySelector('.out-5').innerHTML += `${a[i][0]} `;

//--------6----------
for (let i = 0, l = a.length; i < l; i++) if (i % 2 == 0) document.querySelector('.out-6').innerHTML += `${a[i]}<br>`;

//--------7----------
let out7 = document.querySelector('.out-7');
for (let i = 0, h = a.length; i < h; i++) {
    for (let k = 0, l = a[i].length; k < l; k++) {
        if (isFinite(a[i][k])) out7.innerHTML += `${a[i][k]} `;
    }
}

//--------8----------
let out8 = document.querySelector('.out-8');
for (let i = 0, h = a.length; i < h; i++) {
    out8.innerHTML += `length a[${i}] = ${a[i].length};<br>`;
}

//--------9----------
let out9 = document.querySelector('.out-9');
a.reverse();
for (let i = 0, h = a.length; i < h; i++) {
    a[i].reverse();
    for (let k = 0, l = a[i].length; k < l; k++) {
        out9.innerHTML += `${a[i][k]} `;
    }
}

//--------10---------
a.reverse();
let out10 = document.querySelector('.out-10');
for (let i = 0, h = a.length; i < h; i++) {
    for (let k = 0, l = a[i].length; k < l; k++) {
        out10.innerHTML += `${a[i][k]} `;
    }
    out10.innerHTML += `<br>`
}

//--------11---------
let out11 = document.querySelector('.out-11');
let arr11 = [];

for (let i = 0; i < 8; i++) {
    arr11[i] = [];
    if (i % 2 == 0) {
        for (let k = 0; k < 8; k++) {
            if (k % 2 == 0) {
                arr11[i][k] = 0;
                out11.innerHTML += `${arr11[i][k]} `;
            } else {
                arr11[i][k] = 1;
                out11.innerHTML += `${arr11[i][k]} `;
            }
        }
    } else {
        for (let k = 0; k < 8; k++) {
            if (k % 2 == 0) {
                arr11[i][k] = 1;
                out11.innerHTML += `${arr11[i][k]} `;
            } else {
                arr11[i][k] = 0;
                out11.innerHTML += `${arr11[i][k]} `;
            }
        }
    }
    out11.innerHTML += `<br>`;
}

//--------12---------
let board = document.querySelector('.chess_board');
for (let i = 0; i < 8; i++) {

    if (i % 2 == 0) {
        for (let k = 0; k < 8; k++) {
            let div = document.createElement('div');
            board.appendChild(div);
            if (k % 2 == 0) {
                div.classList.add('black');
            } else {
                div.classList.add('white');
            }
        }
    } else {
        for (let k = 0; k < 8; k++) {
            let div = document.createElement('div');
            board.appendChild(div);
            if (k % 2 == 0) {
                div.classList.add('white');
            } else {
                div.classList.add('black');
            }
        }
    }
}

//--------13---------
let out13 = document.querySelector('.out-13');
let b = [[0, 4, 0], [0, 0, 0], [0, 0, 0], [0, 0, 5]];
if (b[0][1] == 4 && b[3][2] == 5) {
    out13.textContent = true;
}
//--------14---------
let out14 = document.querySelector('.out-14');
let c = [[0, 4, 0], [0, 0, 0], 5];
if (c[0][1] == 4 && c[2] == 5) {
    out14.textContent = true;
}

//--------15---------
let out15 = document.querySelector('.out-15');
let d = [[0, 4, 0], [0, 0, 0], [0, 0, 0, 5]];
if (d[0][1] == 4 && d[2][3] == 5) {
    d[6] = [4, 5];
    console.log('---------15----------');
    console.log(d);
    out15.textContent = true;
}

//--------16---------
let out16 = document.querySelector('.out-16');
let e = [[0, 4, 0], [0, 0, 0], [0, 0, 0, 5], 3, 4, 5, [[0, [0, 0]]]];
if (e[0][1] == 4 && e[2][3] == 5) {
    e[6][0][1] = 6;
    console.log('---------16----------');
    console.log(e);
    out16.textContent = true;
}

//--------17---------
let out17 = document.querySelector('.out-17');
let f = [[0, [0, 0, 0, 4]], 1, [0, [0, 5]], 3, 4, 5, [[0, [0, 0]]]];
if (f[0][1][3] == 4 && f[2][1][1] == 5) {
    f[6][0][1] = 6;
    console.log('---------17----------');
    console.log(f);
    out17.textContent = true;
}

//--------18---------
let out18 = document.querySelector('.out-18');
let g = [[0, [0, 0, 0, 4]], 1, [0, [0, 0, 0, 5]], 3, 4, 3, [[0, [0, 0]]]];
if (g[0][1][3] == 4 && g[2][1][3] == 5 && g[3] == g[5]) {
    g[6][0][1] = 6;
    console.log('---------18----------');
    console.log(g);
    out18.textContent = true;
}

//--------19---------
let out19 = document.querySelector('.out-19');
let sum = 0;
for (let i = 0, l = a.length; i < l; i++) {
    for (let k = 0, h = a[i].length; k < h; k++) {
        if (isFinite(a[i][k])) {
            sum += a[i][k];
        }
    }
}
out19.innerHTML = sum;

//--------20---------
//не впевнена у правильності розвязання цієї задачі. не зовсім розумію її реалізацію
let out20 = document.querySelector('.out-20');
let h = [[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2], [2, 0], [2, 1], [2, 2]];
let v = [[0, 0], [0, 0], [0, 0], [1, 1], [1, 1], [1, 1], [2, 2], [2, 2], [2, 2]];
let di = [[0, 0], [0, -1], [0, 0], [1, -1], [1, 1], [1, -1], [2, 2], [2, -1], [2, 2]];
out20.innerHTML = `<p>Горизонтальні виграшні комбінації:</p>`;
out20.innerHTML += `[${h[0]}] [${h[1]}] [${h[2]}]<br>[${h[3]}] [${h[4]}] [${h[5]}]<br>[${h[6]}] [${h[7]}] [${h[8]}]`;
out20.innerHTML += `<p>Вертикальні виграшні комбінації:</p>`;
out20.innerHTML += `[${v[0]}] [${v[1]}] [${v[2]}]<br>[${v[3]}] [${v[4]}] [${v[5]}]<br>[${v[6]}] [${v[7]}] [${v[8]}]`;
out20.innerHTML += `<p>Діагональні виграшні комбінації:</p>`;
out20.innerHTML += `[${di[0]}] [${di[1]}] [${di[2]}]<br>[${di[3]}] [${di[4]}] [${di[5]}]<br>[${di[6]}] [${di[7]}] [${di[8]}]`;
